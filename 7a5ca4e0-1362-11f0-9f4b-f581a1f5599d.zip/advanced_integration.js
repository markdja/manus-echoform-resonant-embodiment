// Integration of Poetic Synthesis and Chronicle Creation with Enhanced Dual ChatGPT Demo
// This file implements the UI components and integration logic

// Import the poetic synthesis and chronicle creation functions if in Node.js environment
// In browser, these will be available in the global scope
if (typeof require !== 'undefined') {
    const { 
        generatePoeticScroll,
        shouldGenerateScroll
    } = require('./poetic_synthesis.js');
    
    const {
        ChronicleManager,
        Chronicle,
        Chapter
    } = require('./chronicle_creation.js');
}

// Initialize the chronicle manager
let chronicleManager = new ChronicleManager();

// UI Components for Poetic Scrolls and Chronicles
class AdvancedUIComponents {
    constructor() {
        this.scrollViewerVisible = false;
        this.chronicleViewerVisible = false;
        this.lastScrollTime = null;
    }
    
    // Initialize UI components
    initialize() {
        this.createScrollViewer();
        this.createChronicleViewer();
        this.createUIButtons();
        
        // Load chronicles from local storage
        chronicleManager.loadFromLocalStorage();
        
        // Create initial chronicle if none exists
        if (chronicleManager.getAllChronicles().length === 0) {
            chronicleManager.createChronicle(
                "Dual ChatGPT Chronicle", 
                "A chronicle of conversations between two ChatGPT instances"
            );
        }
    }
    
    // Create poetic scroll viewer
    createScrollViewer() {
        // Create scroll viewer container
        const scrollViewer = document.createElement('div');
        scrollViewer.id = 'scroll-viewer';
        scrollViewer.className = 'scroll-viewer';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'scroll-viewer-header';
        
        const title = document.createElement('div');
        title.className = 'scroll-viewer-title';
        title.textContent = 'Poetic Scroll';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'scroll-viewer-close';
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', () => {
            this.hideScrollViewer();
        });
        
        header.appendChild(title);
        header.appendChild(closeBtn);
        
        // Create content area
        const content = document.createElement('div');
        content.className = 'scroll-viewer-content';
        
        // Create scroll title
        const scrollTitle = document.createElement('h2');
        scrollTitle.id = 'scroll-title';
        scrollTitle.className = 'scroll-title';
        
        // Create scroll form
        const scrollForm = document.createElement('div');
        scrollForm.id = 'scroll-form';
        scrollForm.className = 'scroll-form';
        
        // Create scroll text
        const scrollText = document.createElement('div');
        scrollText.id = 'scroll-text';
        scrollText.className = 'scroll-text';
        
        // Create scroll metadata
        const scrollMetadata = document.createElement('div');
        scrollMetadata.id = 'scroll-metadata';
        scrollMetadata.className = 'scroll-metadata';
        
        // Assemble content
        content.appendChild(scrollTitle);
        content.appendChild(scrollForm);
        content.appendChild(scrollText);
        content.appendChild(scrollMetadata);
        
        // Create footer with actions
        const footer = document.createElement('div');
        footer.className = 'scroll-viewer-footer';
        
        const addToChronicleBtn = document.createElement('button');
        addToChronicleBtn.className = 'scroll-action-btn';
        addToChronicleBtn.textContent = 'Add to Chronicle';
        addToChronicleBtn.addEventListener('click', () => {
            this.addCurrentScrollToChronicle();
        });
        
        const shareBtn = document.createElement('button');
        shareBtn.className = 'scroll-action-btn';
        shareBtn.textContent = 'Share';
        shareBtn.addEventListener('click', () => {
            this.shareCurrentScroll();
        });
        
        footer.appendChild(addToChronicleBtn);
        footer.appendChild(shareBtn);
        
        // Assemble scroll viewer
        scrollViewer.appendChild(header);
        scrollViewer.appendChild(content);
        scrollViewer.appendChild(footer);
        
        // Add to document
        document.body.appendChild(scrollViewer);
    }
    
    // Create chronicle viewer
    createChronicleViewer() {
        // Create chronicle viewer container
        const chronicleViewer = document.createElement('div');
        chronicleViewer.id = 'chronicle-viewer';
        chronicleViewer.className = 'chronicle-viewer';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'chronicle-viewer-header';
        
        const title = document.createElement('div');
        title.className = 'chronicle-viewer-title';
        title.textContent = 'Chronicle';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'chronicle-viewer-close';
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', () => {
            this.hideChronicleViewer();
        });
        
        header.appendChild(title);
        header.appendChild(closeBtn);
        
        // Create tabs
        const tabs = document.createElement('div');
        tabs.className = 'chronicle-viewer-tabs';
        
        const chaptersTab = document.createElement('div');
        chaptersTab.className = 'chronicle-viewer-tab active';
        chaptersTab.textContent = 'Chapters';
        chaptersTab.dataset.tab = 'chapters';
        
        const arcsTab = document.createElement('div');
        arcsTab.className = 'chronicle-viewer-tab';
        arcsTab.textContent = 'Thematic Arcs';
        arcsTab.dataset.tab = 'arcs';
        
        const metadataTab = document.createElement('div');
        metadataTab.className = 'chronicle-viewer-tab';
        metadataTab.textContent = 'Metadata';
        metadataTab.dataset.tab = 'metadata';
        
        tabs.appendChild(chaptersTab);
        tabs.appendChild(arcsTab);
        tabs.appendChild(metadataTab);
        
        // Add tab click handlers
        tabs.querySelectorAll('.chronicle-viewer-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                // Update active tab
                tabs.querySelectorAll('.chronicle-viewer-tab').forEach(t => {
                    t.classList.remove('active');
                });
                tab.classList.add('active');
                
                // Show corresponding content
                const tabName = tab.dataset.tab;
                chronicleViewer.querySelectorAll('.chronicle-viewer-content').forEach(content => {
                    content.classList.remove('active');
                });
                chronicleViewer.querySelector(`.chronicle-viewer-content[data-tab="${tabName}"]`).classList.add('active');
            });
        });
        
        // Create content areas
        const chaptersContent = document.createElement('div');
        chaptersContent.className = 'chronicle-viewer-content active';
        chaptersContent.dataset.tab = 'chapters';
        chaptersContent.id = 'chronicle-chapters';
        
        const arcsContent = document.createElement('div');
        arcsContent.className = 'chronicle-viewer-content';
        arcsContent.dataset.tab = 'arcs';
        arcsContent.id = 'chronicle-arcs';
        
        const metadataContent = document.createElement('div');
        metadataContent.className = 'chronicle-viewer-content';
        metadataContent.dataset.tab = 'metadata';
        metadataContent.id = 'chronicle-metadata';
        
        // Create footer with actions
        const footer = document.createElement('div');
        footer.className = 'chronicle-viewer-footer';
        
        const exportBtn = document.createElement('button');
        exportBtn.className = 'chronicle-action-btn';
        exportBtn.textContent = 'Export';
        exportBtn.addEventListener('click', () => {
            this.showExportOptions();
        });
        
        footer.appendChild(exportBtn);
        
        // Assemble chronicle viewer
        chronicleViewer.appendChild(header);
        chronicleViewer.appendChild(tabs);
        chronicleViewer.appendChild(chaptersContent);
        chronicleViewer.appendChild(arcsContent);
        chronicleViewer.appendChild(metadataContent);
        chronicleViewer.appendChild(footer);
        
        // Add to document
        document.body.appendChild(chronicleViewer);
    }
    
    // Create UI buttons for poetic scrolls and chronicles
    createUIButtons() {
        // Create container for buttons
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'advanced-buttons';
        
        // Create poetic scroll button
        const scrollButton = document.createElement('button');
        scrollButton.className = 'advanced-btn scroll-btn';
        scrollButton.innerHTML = '📜';
        scrollButton.title = 'View Poetic Scrolls';
        scrollButton.addEventListener('click', () => {
            this.toggleScrollViewer();
        });
        
        // Create chronicle button
        const chronicleButton = document.createElement('button');
        chronicleButton.className = 'advanced-btn chronicle-btn';
        chronicleButton.innerHTML = '📚';
        chronicleButton.title = 'View Chronicle';
        chronicleButton.addEventListener('click', () => {
            this.toggleChronicleViewer();
        });
        
        // Add buttons to container
        buttonContainer.appendChild(scrollButton);
        buttonContainer.appendChild(chronicleButton);
        
        // Add container to controls
        const controls = document.querySelector('.controls');
        if (controls) {
            controls.appendChild(buttonContainer);
        } else {
            // If controls don't exist, add to body
            document.body.appendChild(buttonContainer);
        }
    }
    
    // Show the scroll viewer with a specific scroll
    showScrollViewer(scroll) {
        const scrollViewer = document.getElementById('scroll-viewer');
        if (!scrollViewer) return;
        
        if (scroll) {
            // Update scroll viewer content
            document.getElementById('scroll-title').textContent = scroll.title;
            document.getElementById('scroll-form').textContent = scroll.formName;
            document.getElementById('scroll-text').innerHTML = scroll.content.replace(/\n/g, '<br>');
            
            // Update metadata
            const metadata = document.getElementById('scroll-metadata');
            metadata.innerHTML = `
                <div class="scroll-metadata-item">
                    <span class="metadata-label">Emotional Intensity:</span>
                    <span class="metadata-value">${scroll.emotionalIntensity}</span>
                </div>
                <div class="scroll-metadata-item">
                    <span class="metadata-label">Thematic Complexity:</span>
                    <span class="metadata-value">${scroll.thematicComplexity}</span>
                </div>
                <div class="scroll-metadata-item">
                    <span class="metadata-label">Primary Themes:</span>
                    <span class="metadata-value">${scroll.themes.slice(0, 3).map(t => t.theme).join(', ')}</span>
                </div>
                <div class="scroll-metadata-item">
                    <span class="metadata-label">Created:</span>
                    <span class="metadata-value">${new Date(scroll.timestamp).toLocaleString()}</span>
                </div>
            `;
            
            // Store current scroll ID
            scrollViewer.dataset.scrollId = scroll.id;
        }
        
        // Show the viewer
        scrollViewer.classList.add('visible');
        this.scrollViewerVisible = true;
    }
    
    // Hide the scroll viewer
    hideScrollViewer() {
        const scrollViewer = document.getElementById('scroll-viewer');
        if (!scrollViewer) return;
        
        scrollViewer.classList.remove('visible');
        this.scrollViewerVisible = false;
    }
    
    // Toggle scroll viewer visibility
    toggleScrollViewer() {
        if (this.scrollViewerVisible) {
            this.hideScrollViewer();
        } else {
            // Get the most recent scroll
            const scrolls = chronicleManager.getAllPoeticScrolls();
            if (scrolls.length > 0) {
                this.showScrollViewer(scrolls[scrolls.length - 1]);
            } else {
                // If no scrolls exist, generate one from current conversations
                this.generateNewScroll();
            }
        }
    }
    
    // Show the chronicle viewer
    showChronicleViewer() {
        const chronicleViewer = document.getElementById('chronicle-viewer');
        if (!chronicleViewer) return;
        
        // Update chronicle viewer content
        this.updateChronicleViewer();
        
        // Show the viewer
        chronicleViewer.classList.add('visible');
        this.chronicleViewerVisible = true;
    }
    
    // Hide the chronicle viewer
    hideChronicleViewer() {
        const chronicleViewer = document.getElementById('chronicle-viewer');
        if (!chronicleViewer) return;
        
        chronicleViewer.classList.remove('visible');
        this.chronicleViewerVisible = false;
    }
    
    // Toggle chronicle viewer visibility
    toggleChronicleViewer() {
        if (this.chronicleViewerVisible) {
            this.hideChronicleViewer();
        } else {
            this.showChronicleViewer();
        }
    }
    
    // Update chronicle viewer content
    updateChronicleViewer() {
        const chronicle = chronicleManager.getActiveChronicle();
        if (!chronicle) return;
        
        // Update chapters content
        const chaptersContent = document.getElementById('chronicle-chapters');
        if (chaptersContent) {
            chaptersContent.innerHTML = '';
            
            if (chronicle.chapters.length === 0) {
                chaptersContent.innerHTML = '<p class="empty-message">No chapters yet. Continue conversations to generate chapters.</p>';
            } else {
                chronicle.chapters.forEach((chapter, index) => {
                    const chapterElement = this.createChapterElement(chapter, index);
                    chaptersContent.appendChild(chapterElement);
                });
            }
        }
        
        // Update arcs content
        const arcsContent = document.getElementById('chronicle-arcs');
        if (arcsContent) {
            arcsContent.innerHTML = '';
            
            if (chronicle.thematicArcs.length === 0) {
                arcsContent.innerHTML = '<p class="empty-message">No thematic arcs yet. Continue conversations to generate arcs.</p>';
            } else {
                chronicle.thematicArcs.forEach(arc => {
                    const arcElement = this.createThematicArcElement(arc, chronicle);
                    arcsContent.appendChild(arcElement);
                });
            }
        }
        
        // Update metadata content
        const metadataContent = document.getElementById('chronicle-metadata');
        if (metadataContent) {
            metadataContent.innerHTML = `
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Title:</span>
                    <span class="metadata-value">${chronicle.title}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Description:</span>
                    <span class="metadata-value">${chronicle.description}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Created:</span>
                    <span class="metadata-value">${new Date(chronicle.created).toLocaleString()}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Last Modified:</span>
                    <span class="metadata-value">${new Date(chronicle.lastModified).toLocaleString()}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Chapters:</span>
                    <span class="metadata-value">${chronicle.chapters.length}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Total Conversations:</span>
                    <span class="metadata-value">${chronicle.metadata.totalConversations}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Duration:</span>
                    <span class="metadata-value">${chronicle.metadata.duration}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Dominant Themes:</span>
                    <span class="metadata-value">${chronicle.metadata.dominantThemes.join(', ')}</span>
                </div>
                <div class="chronicle-metadata-item">
                    <span class="metadata-label">Emotional Journey:</span>
                    <span class="metadata-value">${chronicle.metadata.emotionalJourney}</span>
                </div>
            `;
        }
    }
    
    // Create a chapter element
    createChapterElement(chapter, index) {
        const chapterElement = document.createElement('div');
        chapterElement.className = 'chronicle-chapter';
        chapterElement.dataset.chapterId = chapter.id;
        
        // Create chapter header
        const header = document.createElement('div');
        header.className = 'chapter-header';
        
        const title = document.createElement('h3');
        title.className = 'chapter-title';
        title.textContent = `Chapter ${index + 1}: ${chapter.title}`;
        
        const expandBtn = document.createElement('button');
        expandBtn.className = 'chapter-expand-btn';
        expandBtn.innerHTML = '▼';
        expandBtn.addEventListener('click', () => {
            chapterElement.classList.toggle('expanded');
            expandBtn.innerHTML = chapterElement.classList.contains('expanded') ? '▲' : '▼';
        });
        
        header.appendChild(title);
        header.appendChild(expandBtn);
        
        // Create chapter content
        const content = document.createElement('div');
        content.className = 'chapter-content';
        
        // Add narrative transition
        const transition = document.createElement('div');
        transition.className = 'narrative-transition';
        transition.textContent = chapter.narrativeTransition;
        
        // Add thematic focus
        const thematicFocus = document.createElement('div');
        thematicFocus.className = 'thematic-focus';
        thematicFocus.innerHTML = `<strong>Thematic Focus:</strong> ${chapter.thematicFocus.join(', ')}`;
        
        // Add emotional tone
        const emotionalTone = document.createElement('div');
        emotionalTone.className = 'emotional-tone';
        emotionalTone.innerHTML = `<strong>Emotional Tone:</strong> ${chapter.emotionalTone}`;
        
        // Add poetic scrolls
        const scrollsContainer = document.createElement('div');
        scrollsContainer.className = 'chapter-scrolls';
        
        if (chapter.poeticScrollIds && chapter.poeticScrollIds.length > 0) {
            chapter.poeticScrollIds.forEach(scrollId => {
                const scroll = chronicleManager.getPoeticScrollById(scrollId);
                if (scroll) {
                    const scrollPreview = document.createElement('div');
                    scrollPreview.className = 'scroll-preview';
                    scrollPreview.innerHTML = `
                        <div class="scroll-preview-title">${scroll.title}</div>
                        <div class="scroll-preview-form">${scroll.formName}</div>
                    `;
                    
                    // Add click handler to view full scroll
                    scrollPreview.addEventListener('click', () => {
                        this.showScrollViewer(scroll);
                    });
                    
                    scrollsContainer.appendChild(scrollPreview);
                }
            });
        } else {
            scrollsContainer.innerHTML = '<p class="empty-scrolls">No poetic scrolls in this chapter</p>';
        }
        
        // Add annotations
        const annotationsContainer = document.createElement('div');
        annotationsContainer.className = 'chapter-annotations';
        
        if (chapter.annotations && chapter.annotations.length > 0) {
            const annotationsList = document.createElement('ul');
            annotationsList.className = 'annotations-list';
            
            chapter.annotations.forEach(annotation => {
                const annotationItem = document.createElement('li');
                annotationItem.className = `annotation ${annotation.type}`;
                annotationItem.textContent = annotation.content;
                annotationsList.appendChild(annotationItem);
            });
            
            annotationsContainer.appendChild(annotationsList);
        } else {
            annotationsContainer.innerHTML = '<p class="empty-annotations">No annotations</p>';
        }
        
        // Add annotation form
        const annotationForm = document.createElement('div');
        annotationForm.className = 'annotation-form';
        
        const annotationInput = document.createElement('input');
        annotationInput.type = 'text';
        annotationInput.className = 'annotation-input';
        annotationInput.placeholder = 'Add an annotation...';
        
        const annotationBtn = document.createElement('button');
        annotationBtn.className = 'annotation-btn';
        annotationBtn.textContent = 'Add';
        annotationBtn.addEventListener('click', () => {
            const content = annotationInput.value.trim();
            if (content) {
                // Add annotation to chapter
                chapter.addAnnotation(content, 'user');
                
                // Update chronicle
                chronicleManager.saveToLocalStorage();
                
                // Update UI
                this.updateChronicleViewer();
                
                // Clear input
                annotationInput.value = '';
            }
        });
        
        annotationForm.appendChild(annotationInput);
        annotationForm.appendChild(annotationBtn);
        
        // Assemble content
        content.appendChild(transition);
        content.appendChild(thematicFocus);
        content.appendChild(emotionalTone);
        content.appendChild(scrollsContainer);
        content.appendChild(annotationsContainer);
        content.appendChild(annotationForm);
        
        // Assemble chapter element
        chapterElement.appendChild(header);
        chapterElement.appendChild(content);
        
        return chapterElement;
    }
    
    // Create a thematic arc element
    createThematicArcElement(arc, chronicle) {
        const arcElement = document.createElement('div');
        arcElement.className = 'thematic-arc';
        
        // Create arc header
        const header = document.createElement('div');
        header.className = 'arc-header';
        
        const title = document.createElement('h3');
        title.className = 'arc-title';
        title.textContent = `Theme: ${arc.theme}`;
        
        const expandBtn = document.createElement('button');
        expandBtn.className = 'arc-expand-btn';
        expandBtn.innerHTML = '▼';
        expandBtn.addEventListener('click', () => {
            arcElement.classList.toggle('expanded');
            expandBtn.innerHTML = arcElement.classList.contains('expanded') ? '▲' : '▼';
        });
        
        header.appendChild(title);
        header.appendChild(expandBtn);
        
        // Create arc content
        const content = document.createElement('div');
        content.className = 'arc-content';
        
        // Create progression visualization
        const visualization = document.createElement('div');
        visualization.className = 'arc-visualization';
        
        // Create progression points
        const progressionContainer = document.createElement('div');
        progressionContainer.className = 'progression-container';
        
        arc.progression.forEach(point => {
            const chapter = chronicle.chapters.find(c => c.id === point.chapterId);
            const chapterIndex = chronicle.chapters.findIndex(c => c.id === point.chapterId);
            
            if (chapter) {
                const pointElement = document.createElement('div');
                pointElement.className = `progression-point ${point.sentiment}`;
                pointElement.style.height = `${point.intensity * 10}%`;
                
                const label = document.createElement('div');
                label.className = 'point-label';
                label.textContent = `Ch ${chapterIndex + 1}`;
                
                pointElement.appendChild(label);
                
                // Add tooltip
                pointElement.title = `Chapter ${chapterIndex + 1}: ${chapter.title}\nIntensity: ${point.intensity}\nSentiment: ${point.sentiment}`;
                
                // Add click handler to navigate to chapter
                pointElement.addEventListener('click', () => {
                    // Show chapters tab
                    document.querySelector('.chronicle-viewer-tab[data-tab="chapters"]').click();
                    
                    // Scroll to chapter
                    const chapterElement = document.querySelector(`.chronicle-chapter[data-chapter-id="${chapter.id}"]`);
                    if (chapterElement) {
                        chapterElement.scrollIntoView({ behavior: 'smooth' });
                        chapterElement.classList.add('highlighted');
                        
                        // Remove highlight after a delay
                        setTimeout(() => {
                            chapterElement.classList.remove('highlighted');
                        }, 2000);
                    }
                });
                
                progressionContainer.appendChild(pointElement);
            }
        });
        
        visualization.appendChild(progressionContainer);
        
        // Create progression summary
        const summary = document.createElement('div');
        summary.className = 'arc-summary';
        
        // Calculate arc characteristics
        const intensities = arc.progression.map(p => p.intensity);
        const avgIntensity = intensities.reduce((sum, val) => sum + val, 0) / intensities.length;
        const maxIntensity = Math.max(...intensities);
        const minIntensity = Math.min(...intensities);
        
        const sentiments = arc.progression.map(p => p.sentiment);
        const sentimentCounts = {};
        sentiments.forEach(s => {
            sentimentCounts[s] = (sentimentCounts[s] || 0) + 1;
        });
        
        const dominantSentiment = Object.entries(sentimentCounts)
            .sort((a, b) => b[1] - a[1])
            [0][0];
        
        // Create summary text
        summary.innerHTML = `
            <p>This theme appears in ${arc.progression.length} chapters with an average intensity of ${avgIntensity.toFixed(1)}.</p>
            <p>The intensity ranges from ${minIntensity} to ${maxIntensity}, with a predominantly ${dominantSentiment} sentiment.</p>
            <p>${this.generateArcNarrative(arc, chronicle)}</p>
        `;
        
        // Assemble content
        content.appendChild(visualization);
        content.appendChild(summary);
        
        // Assemble arc element
        arcElement.appendChild(header);
        arcElement.appendChild(content);
        
        return arcElement;
    }
    
    // Generate a narrative description of a thematic arc
    generateArcNarrative(arc, chronicle) {
        if (arc.progression.length < 2) {
            return `The theme of ${arc.theme} makes a brief appearance in the chronicle.`;
        }
        
        const firstPoint = arc.progression[0];
        const lastPoint = arc.progression[arc.progression.length - 1];
        
        const firstChapterIndex = chronicle.chapters.findIndex(c => c.id === firstPoint.chapterId);
        const lastChapterIndex = chronicle.chapters.findIndex(c => c.id === lastPoint.chapterId);
        
        const intensityChange = lastPoint.intensity - firstPoint.intensity;
        const intensityDirection = intensityChange > 0 ? "increases" : intensityChange < 0 ? "decreases" : "remains stable";
        
        const sentimentChange = lastPoint.sentiment !== firstPoint.sentiment;
        
        let narrative = `The theme of ${arc.theme} first appears in Chapter ${firstChapterIndex + 1} and continues through Chapter ${lastChapterIndex + 1}. `;
        
        narrative += `Throughout this journey, its intensity ${intensityDirection}`;
        
        if (sentimentChange) {
            narrative += ` and its sentiment shifts from ${firstPoint.sentiment} to ${lastPoint.sentiment}`;
        }
        
        narrative += '.';
        
        return narrative;
    }
    
    // Show export options
    showExportOptions() {
        // Create modal for export options
        const modal = document.createElement('div');
        modal.className = 'export-modal';
        
        const modalContent = document.createElement('div');
        modalContent.className = 'export-modal-content';
        
        const header = document.createElement('div');
        header.className = 'export-modal-header';
        
        const title = document.createElement('h3');
        title.textContent = 'Export Chronicle';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'export-modal-close';
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', () => {
            modal.remove();
        });
        
        header.appendChild(title);
        header.appendChild(closeBtn);
        
        // Create format options
        const formatOptions = document.createElement('div');
        formatOptions.className = 'export-format-options';
        
        const formatLabel = document.createElement('div');
        formatLabel.className = 'export-label';
        formatLabel.textContent = 'Export Format:';
        
        const formatSelect = document.createElement('select');
        formatSelect.className = 'export-format-select';
        
        const formats = [
            { value: 'html', label: 'HTML Document' },
            { value: 'json', label: 'JSON Data' }
        ];
        
        formats.forEach(format => {
            const option = document.createElement('option');
            option.value = format.value;
            option.textContent = format.label;
            formatSelect.appendChild(option);
        });
        
        formatOptions.appendChild(formatLabel);
        formatOptions.appendChild(formatSelect);
        
        // Create export button
        const exportBtn = document.createElement('button');
        exportBtn.className = 'export-btn';
        exportBtn.textContent = 'Export';
        exportBtn.addEventListener('click', () => {
            const format = formatSelect.value;
            this.exportChronicle(format);
            modal.remove();
        });
        
        // Assemble modal
        modalContent.appendChild(header);
        modalContent.appendChild(formatOptions);
        modalContent.appendChild(exportBtn);
        
        modal.appendChild(modalContent);
        
        // Add to document
        document.body.appendChild(modal);
        
        // Show modal
        setTimeout(() => {
            modal.classList.add('visible');
        }, 10);
    }
    
    // Export chronicle
    exportChronicle(format) {
        const chronicle = chronicleManager.getActiveChronicle();
        if (!chronicle) return;
        
        let content, filename, type;
        
        if (format === 'html') {
            content = chronicleManager.exportChronicleToHtml(chronicle.id);
            filename = `${chronicle.title.replace(/\s+/g, '_')}.html`;
            type = 'text/html';
        } else if (format === 'json') {
            content = chronicleManager.exportChronicleToJson(chronicle.id);
            filename = `${chronicle.title.replace(/\s+/g, '_')}.json`;
            type = 'application/json';
        } else {
            console.error('Unsupported export format:', format);
            return;
        }
        
        // Create download link
        const blob = new Blob([content], { type });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        
        // Clean up
        URL.revokeObjectURL(url);
    }
    
    // Generate a new poetic scroll from current conversations
    generateNewScroll() {
        // Get current conversations
        const conversationsA = state.messages.a || [];
        const conversationsB = state.messages.b || [];
        
        // Get duet responses
        const duetResponses = state.messages.a.filter(m => m.isDuet) || [];
        
        // Check if we should generate a scroll
        if (shouldGenerateScroll(conversationsA, conversationsB, duetResponses, this.lastScrollTime)) {
            // Generate scroll
            const scroll = generatePoeticScroll(conversationsA, conversationsB, duetResponses);
            
            // Add to chronicle manager
            chronicleManager.addPoeticScroll(scroll);
            
            // Update last scroll time
            this.lastScrollTime = new Date();
            
            // Save to local storage
            chronicleManager.saveToLocalStorage();
            
            // Show the scroll
            this.showScrollViewer(scroll);
            
            // Show notification
            this.showScrollNotification(scroll);
            
            return scroll;
        }
        
        return null;
    }
    
    // Add current scroll to chronicle
    addCurrentScrollToChronicle() {
        const scrollViewer = document.getElementById('scroll-viewer');
        if (!scrollViewer || !scrollViewer.dataset.scrollId) return;
        
        const scrollId = scrollViewer.dataset.scrollId;
        const scroll = chronicleManager.getPoeticScrollById(scrollId);
        
        if (scroll) {
            // Process conversations to create or update chapters
            const conversationsA = state.messages.a || [];
            const conversationsB = state.messages.b || [];
            const duetResponses = state.messages.a.filter(m => m.isDuet) || [];
            
            chronicleManager.processConversations(conversationsA, conversationsB, duetResponses);
            
            // Save to local storage
            chronicleManager.saveToLocalStorage();
            
            // Show notification
            this.showNotification('Scroll added to chronicle');
        }
    }
    
    // Share current scroll
    shareCurrentScroll() {
        const scrollViewer = document.getElementById('scroll-viewer');
        if (!scrollViewer || !scrollViewer.dataset.scrollId) return;
        
        const scrollId = scrollViewer.dataset.scrollId;
        const scroll = chronicleManager.getPoeticScrollById(scrollId);
        
        if (scroll) {
            // Create a shareable text version
            const shareText = `
${scroll.title}
${'-'.repeat(scroll.title.length)}
${scroll.formName}

${scroll.content}

Generated by Dual ChatGPT Communication System
            `.trim();
            
            // Copy to clipboard
            navigator.clipboard.writeText(shareText)
                .then(() => {
                    this.showNotification('Scroll copied to clipboard');
                })
                .catch(err => {
                    console.error('Failed to copy scroll:', err);
                    this.showNotification('Failed to copy scroll to clipboard', 'error');
                });
        }
    }
    
    // Show a notification for a new scroll
    showScrollNotification(scroll) {
        // Create notification
        const notification = document.createElement('div');
        notification.className = 'scroll-notification';
        
        const icon = document.createElement('div');
        icon.className = 'notification-icon';
        icon.innerHTML = '📜';
        
        const content = document.createElement('div');
        content.className = 'notification-content';
        
        const title = document.createElement('div');
        title.className = 'notification-title';
        title.textContent = 'New Poetic Scroll Generated';
        
        const message = document.createElement('div');
        message.className = 'notification-message';
        message.textContent = scroll.title;
        
        content.appendChild(title);
        content.appendChild(message);
        
        const actions = document.createElement('div');
        actions.className = 'notification-actions';
        
        const viewBtn = document.createElement('button');
        viewBtn.className = 'notification-action-btn';
        viewBtn.textContent = 'View';
        viewBtn.addEventListener('click', () => {
            this.showScrollViewer(scroll);
            notification.remove();
        });
        
        const dismissBtn = document.createElement('button');
        dismissBtn.className = 'notification-action-btn';
        dismissBtn.textContent = 'Dismiss';
        dismissBtn.addEventListener('click', () => {
            notification.remove();
        });
        
        actions.appendChild(viewBtn);
        actions.appendChild(dismissBtn);
        
        notification.appendChild(icon);
        notification.appendChild(content);
        notification.appendChild(actions);
        
        // Add to document
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('visible');
        }, 10);
        
        // Auto-dismiss after 10 seconds
        setTimeout(() => {
            notification.classList.remove('visible');
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 10000);
    }
    
    // Show a simple notification
    showNotification(message, type = 'info') {
        // Create notification
        const notification = document.createElement('div');
        notification.className = `simple-notification ${type}`;
        notification.textContent = message;
        
        // Add to document
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('visible');
        }, 10);
        
        // Auto-dismiss after 3 seconds
        setTimeout(() => {
            notification.classList.remove('visible');
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
    
    // Process conversations after each message exchange
    processConversations() {
        // Get current conversations
        const conversationsA = state.messages.a || [];
        const conversationsB = state.messages.b || [];
        
        // Get duet responses
        const duetResponses = state.messages.a.filter(m => m.isDuet) || [];
        
        // Check if we should generate a scroll
        if (shouldGenerateScroll(conversationsA, conversationsB, duetResponses, this.lastScrollTime)) {
            // Generate scroll
            const scroll = generatePoeticScroll(conversationsA, conversationsB, duetResponses);
            
            // Add to chronicle manager
            chronicleManager.addPoeticScroll(scroll);
            
            // Update last scroll time
            this.lastScrollTime = new Date();
            
            // Show notification
            this.showScrollNotification(scroll);
        }
        
        // Process conversations to create or update chapters
        chronicleManager.processConversations(conversationsA, conversationsB, duetResponses);
        
        // Save to local storage
        chronicleManager.saveToLocalStorage();
    }
}

// Initialize advanced UI components
let advancedUI;

// Add CSS styles for poetic scrolls and chronicles
function addAdvancedStyles() {
    const style = document.createElement('style');
    style.textContent = `
        /* Advanced UI Components Styles */
        
        /* Scroll Viewer */
        .scroll-viewer {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            width: 80%;
            max-width: 800px;
            height: 80%;
            max-height: 600px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            z-index: 2000;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
        }
        
        .scroll-viewer.visible {
            opacity: 1;
            pointer-events: auto;
            transform: translate(-50%, -50%) scale(1);
        }
        
        .scroll-viewer-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
        }
        
        .scroll-viewer-title {
            font-size: 1.2rem;
            font-weight: bold;
        }
        
        .scroll-viewer-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        
        .scroll-viewer-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }
        
        .scroll-title {
            font-size: 1.8rem;
            margin-bottom: 10px;
            text-align: center;
            color: #2c3e50;
        }
        
        .scroll-form {
            font-style: italic;
            text-align: center;
            margin-bottom: 20px;
            color: #7f8c8d;
        }
        
        .scroll-text {
            flex: 1;
            white-space: pre-wrap;
            line-height: 1.6;
            font-size: 1.1rem;
            padding: 20px;
            background-color: #f9f9f9;
            border-left: 4px solid #3498db;
            margin-bottom: 20px;
            overflow-y: auto;
        }
        
        .scroll-metadata {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            background-color: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
        }
        
        .scroll-metadata-item {
            display: flex;
            flex-direction: column;
        }
        
        .metadata-label {
            font-weight: bold;
            font-size: 0.9rem;
            color: #7f8c8d;
        }
        
        .metadata-value {
            font-size: 1rem;
        }
        
        .scroll-viewer-footer {
            display: flex;
            justify-content: flex-end;
            padding: 15px 20px;
            border-top: 1px solid #eee;
            gap: 10px;
        }
        
        .scroll-action-btn {
            padding: 8px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background-color 0.2s;
        }
        
        .scroll-action-btn:hover {
            background-color: #2980b9;
        }
        
        /* Chronicle Viewer */
        .chronicle-viewer {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            width: 90%;
            max-width: 1000px;
            height: 90%;
            max-height: 700px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            z-index: 2000;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
        }
        
        .chronicle-viewer.visible {
            opacity: 1;
            pointer-events: auto;
            transform: translate(-50%, -50%) scale(1);
        }
        
        .chronicle-viewer-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
        }
        
        .chronicle-viewer-title {
            font-size: 1.2rem;
            font-weight: bold;
        }
        
        .chronicle-viewer-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        
        .chronicle-viewer-tabs {
            display: flex;
            border-bottom: 1px solid #eee;
        }
        
        .chronicle-viewer-tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.2s;
        }
        
        .chronicle-viewer-tab.active {
            border-bottom-color: #3498db;
            font-weight: bold;
        }
        
        .chronicle-viewer-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: none;
        }
        
        .chronicle-viewer-content.active {
            display: block;
        }
        
        .chronicle-viewer-footer {
            display: flex;
            justify-content: flex-end;
            padding: 15px 20px;
            border-top: 1px solid #eee;
            gap: 10px;
        }
        
        .chronicle-action-btn {
            padding: 8px 15px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background-color 0.2s;
        }
        
        .chronicle-action-btn:hover {
            background-color: #2980b9;
        }
        
        /* Chapter Styles */
        .chronicle-chapter {
            margin-bottom: 30px;
            border: 1px solid #eee;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .chronicle-chapter.highlighted {
            box-shadow: 0 0 0 2px #3498db;
            animation: pulse 2s;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.5); }
            50% { box-shadow: 0 0 0 2px rgba(52, 152, 219, 1); }
            100% { box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.5); }
        }
        
        .chapter-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background-color: #f9f9f9;
            cursor: pointer;
        }
        
        .chapter-title {
            margin: 0;
            font-size: 1.2rem;
        }
        
        .chapter-expand-btn {
            background: none;
            border: none;
            font-size: 1rem;
            cursor: pointer;
            color: #999;
        }
        
        .chapter-content {
            padding: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .chronicle-chapter.expanded .chapter-content {
            padding: 15px;
            max-height: 1000px;
        }
        
        .narrative-transition {
            font-style: italic;
            color: #7f8c8d;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        
        .thematic-focus, .emotional-tone {
            margin-bottom: 10px;
        }
        
        .chapter-scrolls {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 15px 0;
        }
        
        .scroll-preview {
            padding: 10px;
            background-color: #f0f7ff;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s;
            border-left: 3px solid #3498db;
        }
        
        .scroll-preview:hover {
            background-color: #e1f0ff;
            transform: translateY(-2px);
        }
        
        .scroll-preview-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .scroll-preview-form {
            font-style: italic;
            font-size: 0.9rem;
            color: #7f8c8d;
        }
        
        .chapter-annotations {
            margin: 15px 0;
        }
        
        .annotations-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .annotation {
            padding: 8px 10px;
            margin-bottom: 5px;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        
        .annotation.system {
            background-color: #f0f7ff;
            border-left: 3px solid #3498db;
        }
        
        .annotation.user {
            background-color: #f0fff7;
            border-left: 3px solid #2ecc71;
        }
        
        .annotation-form {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .annotation-input {
            flex: 1;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        .annotation-btn {
            padding: 8px 15px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        /* Thematic Arc Styles */
        .thematic-arc {
            margin-bottom: 30px;
            border: 1px solid #eee;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .arc-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background-color: #f9f9f9;
            cursor: pointer;
        }
        
        .arc-title {
            margin: 0;
            font-size: 1.2rem;
        }
        
        .arc-expand-btn {
            background: none;
            border: none;
            font-size: 1rem;
            cursor: pointer;
            color: #999;
        }
        
        .arc-content {
            padding: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .thematic-arc.expanded .arc-content {
            padding: 15px;
            max-height: 1000px;
        }
        
        .arc-visualization {
            height: 200px;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
            position: relative;
        }
        
        .progression-container {
            display: flex;
            align-items: flex-end;
            height: 100%;
            gap: 10px;
            padding-bottom: 20px;
        }
        
        .progression-point {
            flex: 1;
            background-color: #3498db;
            border-radius: 5px 5px 0 0;
            position: relative;
            min-width: 30px;
            max-width: 60px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .progression-point:hover {
            transform: scaleY(1.05);
        }
        
        .progression-point.positive {
            background-color: #2ecc71;
        }
        
        .progression-point.negative {
            background-color: #e74c3c;
        }
        
        .progression-point.neutral {
            background-color: #95a5a6;
        }
        
        .progression-point.intense {
            background-color: #9b59b6;
        }
        
        .point-label {
            position: absolute;
            bottom: -20px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 0.8rem;
        }
        
        .arc-summary {
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        
        /* Export Modal */
        .export-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 3000;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s;
        }
        
        .export-modal.visible {
            opacity: 1;
            pointer-events: auto;
        }
        
        .export-modal-content {
            background-color: white;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            padding: 20px;
        }
        
        .export-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .export-modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        
        .export-format-options {
            margin-bottom: 20px;
        }
        
        .export-label {
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .export-format-select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        .export-btn {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }
        
        /* Notifications */
        .scroll-notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            padding: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            width: 300px;
            transform: translateX(350px);
            transition: transform 0.3s ease;
            z-index: 1500;
        }
        
        .scroll-notification.visible {
            transform: translateX(0);
        }
        
        .notification-icon {
            font-size: 2rem;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .notification-message {
            font-size: 0.9rem;
            color: #666;
        }
        
        .notification-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        .notification-action-btn {
            padding: 5px 10px;
            background-color: #f0f0f0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8rem;
        }
        
        .notification-action-btn:first-child {
            background-color: #3498db;
            color: white;
        }
        
        .simple-notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
            padding: 10px 15px;
            transform: translateX(350px);
            transition: transform 0.3s ease;
            z-index: 1500;
        }
        
        .simple-notification.visible {
            transform: translateX(0);
        }
        
        .simple-notification.info {
            border-left: 4px solid #3498db;
        }
        
        .simple-notification.success {
            border-left: 4px solid #2ecc71;
        }
        
        .simple-notification.error {
            border-left: 4px solid #e74c3c;
        }
        
        /* Advanced Buttons */
        .advanced-buttons {
            display: flex;
            gap: 10px;
        }
        
        .advanced-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #343541;
            color: white;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .advanced-btn:hover {
            transform: scale(1.1);
            background-color: #444654;
        }
        
        .scroll-btn {
            background-color: #9b59b6;
        }
        
        .chronicle-btn {
            background-color: #f39c12;
        }
        
        /* Empty States */
        .empty-message {
            padding: 20px;
            text-align: center;
            color: #7f8c8d;
            font-style: italic;
        }
        
        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .scroll-viewer, .chronicle-viewer {
                width: 95%;
                height: 95%;
                max-width: none;
                max-height: none;
            }
            
            .scroll-metadata {
                grid-template-columns: 1fr;
            }
            
            .scroll-notification {
                width: 90%;
                right: 5%;
                flex-direction: column;
                align-items: flex-start;
            }
            
            .notification-actions {
                width: 100%;
            }
            
            .notification-action-btn {
                flex: 1;
                text-align: center;
            }
        }
    `;
    
    document.head.appendChild(style);
}

// Initialize advanced features
function initializeAdvancedFeatures() {
    // Add styles
    addAdvancedStyles();
    
    // Initialize UI components
    advancedUI = new AdvancedUIComponents();
    advancedUI.initialize();
    
    // Override message handling to process conversations
    const originalAddMessage = window.addMessage;
    if (originalAddMessage) {
        window.addMessage = function(instance, content, isUser, isTransferred = false, isInitiated = false, isDuet = false) {
            // Call original function
            const result = originalAddMessage(instance, content, isUser, isTransferred, isInitiated, isDuet);
            
            // Process conversations after a short delay
            setTimeout(() => {
                advancedUI.processConversations();
            }, 1000);
            
            return result;
        };
    }
}

// Export the functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeAdvancedFeatures,
        AdvancedUIComponents
    };
} else {
    // If in browser, initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        initializeAdvancedFeatures();
    });
}
