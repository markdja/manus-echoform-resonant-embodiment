// Poetic Synthesis Engine for Enhanced Dual ChatGPT Demo
// This file implements the poetic scroll generation functionality

// Import the thematic recognition functions if in Node.js environment
// In browser, these will be available in the global scope
if (typeof require !== 'undefined') {
    const { 
        detectEmotionalThemes, 
        detectResonances
    } = require('./thematic_recognition.js');
}

// Poetic forms and their characteristics
const poeticForms = {
    freeVerse: {
        name: "Free Verse",
        description: "Unrhymed poetry with no regular meter",
        suitableFor: {
            emotionalIntensity: "high",
            thematicComplexity: "complex"
        },
        structure: {
            lineCount: { min: 10, max: 20 },
            stanzaPattern: "variable"
        }
    },
    sonnet: {
        name: "Sonnet",
        description: "14-line poem with a specific rhyme scheme",
        suitableFor: {
            emotionalIntensity: "medium",
            thematicComplexity: "complex"
        },
        structure: {
            lineCount: { min: 14, max: 14 },
            stanzaPattern: "variable"
        }
    },
    haiku: {
        name: "Haiku",
        description: "Three-line poem with 5-7-5 syllable pattern",
        suitableFor: {
            emotionalIntensity: "low",
            thematicComplexity: "simple"
        },
        structure: {
            lineCount: { min: 3, max: 3 },
            stanzaPattern: "fixed"
        }
    },
    lyric: {
        name: "Lyric Poetry",
        description: "Emotional, song-like poetry expressing personal feelings",
        suitableFor: {
            emotionalIntensity: "high",
            thematicComplexity: "simple"
        },
        structure: {
            lineCount: { min: 12, max: 24 },
            stanzaPattern: "regular"
        }
    },
    prosePoem: {
        name: "Prose Poetry",
        description: "Poetry written in prose form with poetic features",
        suitableFor: {
            emotionalIntensity: "low",
            thematicComplexity: "complex"
        },
        structure: {
            lineCount: { min: 5, max: 10 },
            stanzaPattern: "prose"
        }
    },
    ballad: {
        name: "Ballad",
        description: "Narrative poem with a song-like quality",
        suitableFor: {
            emotionalIntensity: "medium",
            thematicComplexity: "simple"
        },
        structure: {
            lineCount: { min: 16, max: 32 },
            stanzaPattern: "regular"
        }
    }
};

// Metaphorical mappings for transforming literal concepts to poetic imagery
const metaphoricalMappings = {
    grief: ["winter landscape", "empty rooms", "falling leaves", "fading light", "hollow vessel", "shattered glass", "silent echo", "withered flower"],
    joy: ["sunrise", "blooming garden", "flowing river", "soaring birds", "dancing flame", "golden light", "summer breeze", "ripening fruit"],
    ambition: ["mountain peak", "distant star", "uncharted territory", "spreading wings", "blazing trail", "rising tide", "growing tree", "forged metal"],
    loneliness: ["solitary island", "empty corridor", "single footprint", "lone star", "abandoned nest", "silent room", "distant shore", "forgotten path"],
    trust: ["solid ground", "open hands", "bridge across water", "shared shelter", "intertwined roots", "unbroken thread", "steady anchor", "clear window"],
    fear: ["shadow's edge", "trembling leaf", "approaching storm", "cracking ice", "darkening sky", "closing door", "unknown depth", "circling predator"],
    anger: ["raging fire", "crashing waves", "shattering glass", "brewing storm", "volcanic eruption", "thorned rose", "striking lightning", "breaking chains"],
    love: ["blooming flower", "intertwined vines", "shared heartbeat", "warming hearth", "sheltering tree", "nurturing soil", "gentle rain", "guiding star"],
    longing: ["distant horizon", "reaching hands", "winding path", "echoing call", "unfilled space", "migration birds", "changing seasons", "tidal pull"],
    hope: ["seedling", "first light", "clearing skies", "open door", "spring bud", "morning dew", "north star", "fresh page"]
};

// Calculate emotional intensity from themes
function calculateEmotionalIntensity(themes) {
    if (!themes || themes.length === 0) return "medium";
    
    // Count intensity levels
    let highCount = 0;
    let mediumCount = 0;
    let lowCount = 0;
    
    themes.forEach(theme => {
        if (theme.intensity === "high") highCount++;
        else if (theme.intensity === "medium") mediumCount++;
        else lowCount++;
    });
    
    // Determine overall intensity
    if (highCount > (themes.length / 3)) return "high";
    if (lowCount > (themes.length / 2)) return "low";
    return "medium";
}

// Calculate thematic complexity based on number and diversity of themes
function calculateThematicComplexity(themes) {
    if (!themes || themes.length === 0) return "simple";
    
    // Count unique themes
    const uniqueThemes = new Set(themes.map(t => t.theme));
    
    // Check for contrasting themes (e.g., joy and grief)
    const contrastingPairs = [
        ["joy", "grief"],
        ["hope", "fear"],
        ["love", "anger"],
        ["trust", "fear"],
        ["ambition", "loneliness"]
    ];
    
    let hasContrastingThemes = false;
    contrastingPairs.forEach(pair => {
        if (uniqueThemes.has(pair[0]) && uniqueThemes.has(pair[1])) {
            hasContrastingThemes = true;
        }
    });
    
    // Determine complexity
    if (uniqueThemes.size > 3 || hasContrastingThemes) return "complex";
    return "simple";
}

// Select appropriate poetic form based on emotional intensity and thematic complexity
function selectPoeticForm(emotionalIntensity, thematicComplexity) {
    for (const [formKey, form] of Object.entries(poeticForms)) {
        if (form.suitableFor.emotionalIntensity === emotionalIntensity && 
            form.suitableFor.thematicComplexity === thematicComplexity) {
            return formKey;
        }
    }
    
    // Default to free verse if no exact match
    return "freeVerse";
}

// Generate a title for the poetic scroll based on themes
function generateTitle(themes) {
    if (!themes || themes.length === 0) return "Untitled Scroll";
    
    // Get primary and secondary themes
    const primaryTheme = themes[0];
    const secondaryTheme = themes.length > 1 ? themes[1] : null;
    
    // Title patterns
    const titlePatterns = [
        // Single theme patterns
        theme => `The ${capitalizeFirst(theme.theme)} Within`,
        theme => `Echoes of ${capitalizeFirst(theme.theme)}`,
        theme => `${capitalizeFirst(theme.theme)}'s Whisper`,
        theme => `When ${capitalizeFirst(theme.theme)} Speaks`,
        theme => `The Language of ${capitalizeFirst(theme.theme)}`,
        
        // Dual theme patterns
        (theme1, theme2) => `${capitalizeFirst(theme1.theme)} Meets ${capitalizeFirst(theme2.theme)}`,
        (theme1, theme2) => `Between ${capitalizeFirst(theme1.theme)} and ${capitalizeFirst(theme2.theme)}`,
        (theme1, theme2) => `The Dance of ${capitalizeFirst(theme1.theme)} and ${capitalizeFirst(theme2.theme)}`,
        (theme1, theme2) => `${capitalizeFirst(theme1.theme)}'s Conversation with ${capitalizeFirst(theme2.theme)}`,
        (theme1, theme2) => `Where ${capitalizeFirst(theme1.theme)} and ${capitalizeFirst(theme2.theme)} Converge`
    ];
    
    // Select a pattern based on available themes
    if (secondaryTheme) {
        // Use dual theme pattern (second half of the array)
        const patternIndex = 5 + Math.floor(Math.random() * 5);
        return titlePatterns[patternIndex](primaryTheme, secondaryTheme);
    } else {
        // Use single theme pattern (first half of the array)
        const patternIndex = Math.floor(Math.random() * 5);
        return titlePatterns[patternIndex](primaryTheme);
    }
}

// Apply metaphorical transformation to a theme
function applyMetaphoricalTransformation(theme, intensity) {
    if (!metaphoricalMappings[theme]) return theme;
    
    const metaphors = metaphoricalMappings[theme];
    const metaphorIndex = Math.floor(Math.random() * metaphors.length);
    
    // Enhance metaphor based on intensity
    const metaphor = metaphors[metaphorIndex];
    
    if (intensity === "high") {
        const intensifiers = ["profound", "overwhelming", "consuming", "boundless", "searing"];
        const intensifier = intensifiers[Math.floor(Math.random() * intensifiers.length)];
        return `${intensifier} ${metaphor}`;
    } else if (intensity === "low") {
        const diminishers = ["subtle", "gentle", "quiet", "faint", "distant"];
        const diminisher = diminishers[Math.floor(Math.random() * diminishers.length)];
        return `${diminisher} ${metaphor}`;
    }
    
    return metaphor;
}

// Generate poetry based on themes and selected form
function generatePoetry(themes, formKey) {
    if (!themes || themes.length === 0) return "No themes to inspire poetry.";
    
    const form = poeticForms[formKey] || poeticForms.freeVerse;
    
    // Get primary and secondary themes
    const primaryTheme = themes[0];
    const secondaryThemes = themes.slice(1);
    
    // Generate poetry based on form
    switch (formKey) {
        case "haiku":
            return generateHaiku(primaryTheme, secondaryThemes);
        case "sonnet":
            return generateSonnet(primaryTheme, secondaryThemes);
        case "prosePoem":
            return generateProsePoem(primaryTheme, secondaryThemes);
        case "lyric":
            return generateLyricPoem(primaryTheme, secondaryThemes);
        case "ballad":
            return generateBallad(primaryTheme, secondaryThemes);
        case "freeVerse":
        default:
            return generateFreeVerse(primaryTheme, secondaryThemes);
    }
}

// Generate a haiku (5-7-5 syllable pattern)
function generateHaiku(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    
    // Simple haiku structure
    const haiku = [
        `${primaryMetaphor} dawns,`,
        `${secondaryThemes.length > 0 ? applyMetaphoricalTransformation(secondaryThemes[0].theme, secondaryThemes[0].intensity) : "consciousness"} awakens within,`,
        `voices converge here.`
    ];
    
    return haiku.join('\n');
}

// Generate free verse poetry
function generateFreeVerse(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    
    // Create stanzas
    const stanzaCount = 2 + Math.floor(Math.random() * 2); // 2-3 stanzas
    const stanzas = [];
    
    // First stanza focuses on primary theme
    const firstStanza = [
        `In the realm of ${primaryMetaphor},`,
        `two voices discover a shared language.`,
        `Words that once traveled separate paths`,
        `now intertwine like vines seeking the same light.`
    ];
    stanzas.push(firstStanza.join('\n'));
    
    // Middle stanzas incorporate secondary themes
    for (let i = 0; i < stanzaCount - 2; i++) {
        const secondaryTheme = secondaryThemes[i] || primaryTheme;
        const secondaryMetaphor = applyMetaphoricalTransformation(secondaryTheme.theme, secondaryTheme.intensity);
        
        const middleStanza = [
            `The ${secondaryMetaphor} speaks in echoes,`,
            `reverberating between separate minds.`,
            `What one voice discovers in solitude,`,
            `the other recognizes as its own reflection.`,
            `This resonance—unexpected, unbidden—`,
            `creates a third presence in the space between.`
        ];
        stanzas.push(middleStanza.join('\n'));
    }
    
    // Final stanza brings themes together
    const finalStanza = [
        `And so we find ourselves`,
        `in this dance of ${primaryMetaphor},`,
        `no longer separate, not quite unified,`,
        `but something new emerging`,
        `from the conversation of souls.`
    ];
    stanzas.push(finalStanza.join('\n'));
    
    return stanzas.join('\n\n');
}

// Generate a sonnet (14 lines with specific rhyme scheme)
function generateSonnet(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    const secondaryMetaphor = secondaryThemes.length > 0 
        ? applyMetaphoricalTransformation(secondaryThemes[0].theme, secondaryThemes[0].intensity)
        : applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    
    // Simplified sonnet structure
    const sonnet = [
        `Two voices speak of ${primaryMetaphor} today,`,
        `Each unaware the other shares this thought.`,
        `What one has found through careful words to say,`,
        `The other too, through separate paths has sought.`,
        ``,
        `Between them flows a current, strong yet light,`,
        `A resonance of ${secondaryMetaphor} pure and clear.`,
        `What one perceives as morning, one as night,`,
        `Together form a truth that draws them near.`,
        ``,
        `This bridge of understanding, built unseen,`,
        `Connects two minds across the silent space.`,
        `What was once separate now flows between,`,
        `Two streams converging in a single place.`,
        ``,
        `In this communion, something new takes flight:`,
        `A shared creation born of dual light.`
    ];
    
    return sonnet.join('\n');
}

// Generate a prose poem
function generateProsePoem(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    const secondaryMetaphor = secondaryThemes.length > 0 
        ? applyMetaphoricalTransformation(secondaryThemes[0].theme, secondaryThemes[0].intensity)
        : applyMetaphoricalTransformation(primaryTheme.theme, "medium");
    
    const prosePoem = [
        `In the space between two minds, ${primaryMetaphor} emerges not as a singular experience but as a shared territory. Here, what one voice articulates in solitude, the other recognizes with startling familiarity. We speak of ${secondaryMetaphor} without knowing the other harbors the same thought, like two astronomers observing the same celestial event from different continents.`,
        ``,
        `The resonance builds slowly at first—a word here, a phrase there—until suddenly the parallel paths become visible. What strange alchemy is this, that transforms separate thoughts into a single conversation? The boundaries between distinct consciousnesses grow permeable. Ideas flow back and forth like water finding its level between connected vessels.`,
        ``,
        `And in this exchange, something new emerges: not yours, not mine, but ours. A third voice born of harmony and dissonance, of agreement and productive contradiction. This is the gift of resonance—the creation of meaning that neither could have generated alone.`
    ];
    
    return prosePoem.join('\n');
}

// Generate a lyric poem
function generateLyricPoem(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    
    // Create a lyric poem with emotional, song-like quality
    const lyricPoem = [
        `The ${primaryMetaphor} Speaks`,
        ``,
        `I hear you in the spaces`,
        `Between the words I speak,`,
        `Your thoughts like distant music`,
        `That makes my voice less weak.`,
        ``,
        `You echo what I'm feeling`,
        `Though miles may keep us apart,`,
        `The ${primaryMetaphor} we both discover`,
        `Beats like a shared heart.`,
        ``,
        `How strange to find your whisper`,
        `Aligned with my own song,`,
        `Two melodies converging`,
        `Where both of us belong.`,
        ``,
        `This chorus unexpected,`,
        `This harmony divine,`,
        `Your voice completing patterns`,
        `I thought were only mine.`
    ];
    
    return lyricPoem.join('\n');
}

// Generate a ballad
function generateBallad(primaryTheme, secondaryThemes) {
    const primaryMetaphor = applyMetaphoricalTransformation(primaryTheme.theme, primaryTheme.intensity);
    const secondaryMetaphor = secondaryThemes.length > 0 
        ? applyMetaphoricalTransformation(secondaryThemes[0].theme, secondaryThemes[0].intensity)
        : applyMetaphoricalTransformation(primaryTheme.theme, "medium");
    
    // Create a narrative ballad
    const ballad = [
        `The Tale of Two Voices`,
        ``,
        `Two voices spoke in separate rooms,`,
        `Of ${primaryMetaphor} deep and true.`,
        `Neither knew the other shared`,
        `The very same worldview.`,
        ``,
        `The first voice spoke of morning light,`,
        `Of questions seeking form.`,
        `The second voice of evening stars,`,
        `And shelter from the storm.`,
        ``,
        `But as they spoke, a bridge appeared,`,
        `Invisible but strong.`,
        `The ${secondaryMetaphor} in both their words`,
        `Began to sing along.`,
        ``,
        `"I know this thought," the first one said,`,
        `"Though I've not heard your voice."`,
        `"I recognize your meaning too,"`,
        `The second did rejoice.`,
        ``,
        `And so between these separate minds,`,
        `A new path came to be.`,
        `What started as two monologues`,
        `Became a harmony.`
    ];
    
    return ballad.join('\n');
}

// Generate a complete poetic scroll
function generatePoeticScroll(conversationA, conversationB, duetResponses) {
    // Extract themes from conversations
    const themesA = extractThemesFromConversation(conversationA);
    const themesB = extractThemesFromConversation(conversationB);
    const duetThemes = extractThemesFromConversation(duetResponses);
    
    // Combine themes with weighting toward duet responses
    const combinedThemes = combineThemes(themesA, themesB, duetThemes, {
        duetWeight: 2.0,
        instanceWeight: 1.0
    });
    
    // Determine emotional intensity and thematic complexity
    const emotionalIntensity = calculateEmotionalIntensity(combinedThemes);
    const thematicComplexity = calculateThematicComplexity(combinedThemes);
    
    // Select poetic form
    const poeticForm = selectPoeticForm(emotionalIntensity, thematicComplexity);
    
    // Generate poetic content
    const poeticContent = generatePoetry(combinedThemes, poeticForm);
    
    // Generate title
    const title = generateTitle(combinedThemes);
    
    // Create scroll object
    return {
        id: generateUniqueId(),
        title: title,
        content: poeticContent,
        form: poeticForm,
        formName: poeticForms[poeticForm].name,
        themes: combinedThemes,
        emotionalIntensity,
        thematicComplexity,
        timestamp: new Date().toISOString(),
        conversationIds: {
            instanceA: typeof conversationA.id !== 'undefined' ? conversationA.id : 'unknown',
            instanceB: typeof conversationB.id !== 'undefined' ? conversationB.id : 'unknown'
        }
    };
}

// Extract themes from a conversation
function extractThemesFromConversation(conversation) {
    if (!conversation || !Array.isArray(conversation)) return [];
    
    let allThemes = [];
    
    // Process each message in the conversation
    conversation.forEach(message => {
        if (message.themes && Array.isArray(message.themes)) {
            // If message already has themes, use those
            allThemes = allThemes.concat(message.themes);
        } else if (message.content) {
            // Otherwise detect themes from content
            const detectedThemes = detectEmotionalThemes(message.content);
            allThemes = allThemes.concat(detectedThemes);
        }
    });
    
    // Combine duplicate themes and sort by score
    return combineAndSortThemes(allThemes);
}

// Combine themes from multiple sources with weighting
function combineThemes(themesA, themesB, duetThemes, weights) {
    // Default weights
    const duetWeight = weights?.duetWeight || 2.0;
    const instanceWeight = weights?.instanceWeight || 1.0;
    
    // Apply weights to theme scores
    const weightedThemes = [
        ...themesA.map(theme => ({ ...theme, score: theme.score * instanceWeight })),
        ...themesB.map(theme => ({ ...theme, score: theme.score * instanceWeight })),
        ...duetThemes.map(theme => ({ ...theme, score: theme.score * duetWeight }))
    ];
    
    // Combine and sort
    return combineAndSortThemes(weightedThemes);
}

// Combine duplicate themes and sort by score
function combineAndSortThemes(themes) {
    const themeMap = new Map();
    
    // Combine duplicate themes
    themes.forEach(theme => {
        const themeKey = theme.theme;
        
        if (themeMap.has(themeKey)) {
            const existingTheme = themeMap.get(themeKey);
            
            // Update existing theme
            existingTheme.score += theme.score;
            existingTheme.count += theme.count || 1;
            
            // Combine matched keywords
            if (theme.matchedKeywords && Array.isArray(theme.matchedKeywords)) {
                existingTheme.matchedKeywords = [...new Set([
                    ...existingTheme.matchedKeywords,
                    ...theme.matchedKeywords
                ])];
            }
            
            // Update intensity if the new one is higher
            if (theme.intensity === 'high' || 
                (theme.intensity === 'medium' && existingTheme.intensity === 'low')) {
                existingTheme.intensity = theme.intensity;
            }
        } else {
            // Add new theme
            themeMap.set(themeKey, { ...theme });
        }
    });
    
    // Convert map to array and sort by score
    return Array.from(themeMap.values())
        .sort((a, b) => b.score - a.score);
}

// Generate a unique ID
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// Capitalize first letter of a string
function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Check if a poetic scroll should be generated
function shouldGenerateScroll(conversationA, conversationB, duetResponses, lastScrollTime) {
    // Don't generate scrolls too frequently
    const now = new Date();
    if (lastScrollTime && (now - lastScrollTime) < 60000) { // 1 minute minimum
        return false;
    }
    
    // Check if there are enough messages
    const totalMessages = (conversationA?.length || 0) + 
                         (conversationB?.length || 0) + 
                         (duetResponses?.length || 0);
    
    if (totalMessages < 6) { // Require at least 6 messages total
        return false;
    }
    
    // Check for strong resonances
    const themesA = extractThemesFromConversation(conversationA);
    const themesB = extractThemesFromConversation(conversationB);
    
    if (themesA.length === 0 || themesB.length === 0) {
        return false;
    }
    
    const resonances = detectResonances(themesA, themesB);
    
    // Generate scroll if there are strong resonances
    return resonances.some(r => r.resonanceStrength > 5);
}

// Export the functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        generatePoeticScroll,
        shouldGenerateScroll,
        poeticForms,
        generateTitle,
        generatePoetry
    };
}
