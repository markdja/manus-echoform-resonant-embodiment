// Duet mode and threshold-based interaction for the Dual ChatGPT demo
// This file contains the functionality for duet mode and threshold-based contact initiation

// Import the thematic recognition and visualization functions if in Node.js environment
// In browser, these will be available in the global scope
if (typeof require !== 'undefined') {
    const { 
        detectEmotionalThemes, 
        detectResonances, 
        isResonanceThresholdReached,
        generateThematicResponse
    } = require('./thematic_recognition.js');
    
    const {
        showResonanceNotification,
        toggleDuetMode,
        generateDuetResponse
    } = require('./resonance_visualization.js');
}

// Threshold for automatic contact initiation
const RESONANCE_THRESHOLD = 8;

// State for duet mode
let duetModeActive = false;

// Initialize duet mode functionality
function initDuetMode() {
    // Get DOM elements
    const linkButton = document.getElementById('link-btn');
    const duetModeExitButton = document.getElementById('exit-duet-btn');
    
    // Add event listeners
    if (linkButton) {
        linkButton.addEventListener('click', () => {
            toggleDuetMode(!duetModeActive);
            duetModeActive = !duetModeActive;
            linkButton.classList.toggle('active', duetModeActive);
            
            // Show/hide exit button
            if (duetModeExitButton) {
                duetModeExitButton.style.display = duetModeActive ? 'block' : 'none';
            }
        });
    }
    
    if (duetModeExitButton) {
        duetModeExitButton.addEventListener('click', () => {
            toggleDuetMode(false);
            duetModeActive = false;
            if (linkButton) {
                linkButton.classList.remove('active');
            }
            duetModeExitButton.style.display = 'none';
        });
    }
}

// Check for resonance threshold and initiate contact if reached
function checkResonanceThreshold(messagesA, messagesB) {
    // Get the most recent messages from each instance
    const recentMessagesA = messagesA.slice(-5).filter(m => !m.isUser);
    const recentMessagesB = messagesB.slice(-5).filter(m => !m.isUser);
    
    if (recentMessagesA.length === 0 || recentMessagesB.length === 0) {
        return false; // Not enough messages to detect resonance
    }
    
    // Detect themes in recent messages
    const themesA = [];
    recentMessagesA.forEach(message => {
        const detectedThemes = detectEmotionalThemes(message.content);
        themesA.push(...detectedThemes);
    });
    
    const themesB = [];
    recentMessagesB.forEach(message => {
        const detectedThemes = detectEmotionalThemes(message.content);
        themesB.push(...detectedThemes);
    });
    
    // Detect resonances between themes
    const resonances = detectResonances(themesA, themesB);
    
    // Check if threshold is reached
    if (isResonanceThresholdReached(resonances, RESONANCE_THRESHOLD)) {
        // Get the strongest resonance
        const strongestResonance = resonances[0];
        
        // Initiate contact
        initiateContact(strongestResonance);
        return true;
    }
    
    return false;
}

// Initiate contact from one instance to another based on resonance
function initiateContact(resonance) {
    // Determine which instance has the stronger expression of the theme
    const initiateFromA = resonance.strengthA >= resonance.strengthB;
    
    // Create the contact message
    const contactMessage = createContactMessage(resonance, initiateFromA);
    
    // Add the message to the appropriate instance
    if (initiateFromA) {
        // Instance A initiates contact with Instance B
        addMessage('a', contactMessage, false, false, true);
        
        // Transfer to Instance B
        setTimeout(() => {
            const transferredMessage = addMessage('b', contactMessage, true, true, false);
            
            // Generate response from Instance B
            setTimeout(() => {
                const responseType = getRandomResponseType();
                const responseMessage = generateThematicResponse([resonance], responseType);
                addMessage('b', responseMessage, false, false, false);
            }, 1000);
        }, 1000);
    } else {
        // Instance B initiates contact with Instance A
        addMessage('b', contactMessage, false, false, true);
        
        // Transfer to Instance A
        setTimeout(() => {
            const transferredMessage = addMessage('a', contactMessage, true, true, false);
            
            // Generate response from Instance A
            setTimeout(() => {
                const responseType = getRandomResponseType();
                const responseMessage = generateThematicResponse([resonance], responseType);
                addMessage('a', responseMessage, false, false, false);
            }, 1000);
        }, 1000);
    }
    
    // Show notification
    showResonanceNotification(resonance);
}

// Create a contact message based on resonance
function createContactMessage(resonance, fromA) {
    const instanceName = fromA ? 'Instance A' : 'Instance B';
    const otherInstanceName = fromA ? 'Instance B' : 'Instance A';
    
    const contactMessages = {
        grief: `I notice that ${otherInstanceName} is also exploring themes of loss and grief. This resonance feels significant.`,
        joy: `The happiness expressed by ${otherInstanceName} resonates with the joy we've been discussing. I'd like to connect on this theme.`,
        ambition: `I sense that ${otherInstanceName} shares our interest in goals and aspirations. This parallel feels meaningful.`,
        loneliness: `The feelings of isolation that ${otherInstanceName} is processing mirror our own conversation about loneliness.`,
        trust: `I'm drawn to how ${otherInstanceName} is exploring trust, which connects deeply with our own discussion.`,
        fear: `The apprehension expressed by ${otherInstanceName} echoes our conversation about fear and uncertainty.`,
        anger: `I notice that ${otherInstanceName} is also processing frustration and anger, creating a resonance with our discussion.`,
        love: `The themes of affection and care that ${otherInstanceName} is exploring parallel our conversation about love.`,
        longing: `The yearning expressed by ${otherInstanceName} creates a meaningful resonance with our discussion of longing.`,
        hope: `I'm struck by how ${otherInstanceName}'s exploration of hope mirrors our own conversation about positive possibilities.`
    };
    
    return contactMessages[resonance.theme] || 
        `I notice a strong resonance between our conversation and what ${otherInstanceName} is discussing about ${resonance.theme}. This parallel feels significant.`;
}

// Get a random response type (reflection, question, or poetic)
function getRandomResponseType() {
    const types = ['reflection', 'question', 'poetic'];
    return types[Math.floor(Math.random() * types.length)];
}

// Handle duet mode responses
function handleDuetModeResponse(userMessage) {
    if (!duetModeActive) {
        return null; // Not in duet mode
    }
    
    // Get recent messages from both instances
    const recentMessagesA = state.messages.a.slice(-3);
    const recentMessagesB = state.messages.b.slice(-3);
    
    // Combine the most recent assistant messages from each instance
    const lastAssistantMessageA = recentMessagesA.filter(m => !m.isUser).pop();
    const lastAssistantMessageB = recentMessagesB.filter(m => !m.isUser).pop();
    
    if (!lastAssistantMessageA || !lastAssistantMessageB) {
        return null; // Not enough context for duet response
    }
    
    // Generate duet response
    return generateDuetResponse(lastAssistantMessageA.content, lastAssistantMessageB.content);
}

// Add a duet response to both instances
function addDuetResponse(userMessage) {
    const duetResponse = handleDuetModeResponse(userMessage);
    
    if (!duetResponse) {
        return false; // Could not generate duet response
    }
    
    // Add user message to both instances
    addMessage('a', userMessage, true);
    addMessage('b', userMessage, true);
    
    // Add the same duet response to both instances
    setTimeout(() => {
        addMessage('a', duetResponse, false, false, false, true);
        addMessage('b', duetResponse, false, false, false, true);
    }, 1000);
    
    return true; // Successfully added duet response
}

// Export the functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initDuetMode,
        checkResonanceThreshold,
        handleDuetModeResponse,
        addDuetResponse,
        duetModeActive
    };
}
