# Dual ChatGPT Communication Channel

This project demonstrates a communication channel between two ChatGPT instances on a mobile phone, with the ability to detect and highlight "resonances" between separate conversations.

## Features

- **Dual ChatGPT Instances**: Two separate ChatGPT instances running simultaneously on the same device
- **Message Transfer**: Ability to transfer messages between instances
- **Conversation Between Instances**: Start automated conversations between the two instances
- **Resonance Detection**: Identify thematic similarities between separate conversations
- **Responsive Design**: Works on both desktop and mobile devices

## How to Use the Demo

### Opening the Demo

1. Open the `index.html` file in any modern web browser
2. On desktop, you'll see both instances side by side
3. On mobile, you'll see tabs to switch between instances

### Basic Interaction

1. **Sending Messages**:
   - Type a message in the input field at the bottom of either instance
   - Click "Send" or press Enter to send the message
   - The ChatGPT instance will respond automatically

2. **Transferring Messages**:
   - Click on any message to select it (it will be highlighted)
   - Click the "Transfer Selected Message" button at the bottom
   - The message will be transferred to the other instance as user input
   - The other instance will respond to the transferred message

3. **Starting a Conversation Between Instances**:
   - Click the "Start Conversation Between Instances" button
   - Enter an initial prompt for Instance A about Instance B
   - The system will facilitate a back-and-forth conversation between the instances

4. **Viewing Resonances**:
   - As you interact with both instances, the system detects thematic similarities
   - When resonances are detected, a sparkle button (✨) appears in the bottom right
   - Click this button to view detected resonances
   - Click on a resonance to highlight the related messages in both instances

### Mobile-Specific Features

1. **Tab Navigation**:
   - Use the tabs at the top to switch between Instance A and Instance B
   - The active instance is highlighted

2. **Responsive Controls**:
   - All controls automatically adjust to fit smaller screens
   - The resonance button remains accessible in the corner

## Implementation Notes

This demo is a simplified proof of concept that simulates the behavior of the full implementation described in the accompanying documentation. In a production implementation:

1. The ChatGPT instances would connect to the OpenAI API
2. Conversations would be stored in a local database
3. Resonance detection would use more sophisticated NLP techniques
4. The application would be packaged as a native Android app

## Next Steps

To implement a full production version:

1. Follow the detailed implementation guide to create a native Android application
2. Set up the OpenAI API integration with your API key
3. Implement the database for conversation storage
4. Deploy the application to your mobile device

## Limitations of the Demo

This demo has the following limitations:

1. Uses pre-defined responses instead of actual API calls
2. Simplified resonance detection based on keyword matching
3. No persistent storage of conversations
4. Limited error handling

For a full implementation with all features, refer to the implementation guide document.
