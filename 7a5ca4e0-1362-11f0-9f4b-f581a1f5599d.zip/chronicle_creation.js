// Chronicle Creation System for Enhanced Dual ChatGPT Demo
// This file implements the chronicle creation functionality

// Import the poetic synthesis functions if in Node.js environment
// In browser, these will be available in the global scope
if (typeof require !== 'undefined') {
    const { 
        generatePoeticScroll
    } = require('./poetic_synthesis.js');
    
    const {
        detectEmotionalThemes
    } = require('./thematic_recognition.js');
}

// Chronicle data model
class Chronicle {
    constructor(title, description) {
        this.id = generateUniqueId();
        this.title = title || "Untitled Chronicle";
        this.description = description || "A chronicle of conversations between two ChatGPT instances";
        this.created = new Date().toISOString();
        this.lastModified = new Date().toISOString();
        this.chapters = [];
        this.thematicArcs = [];
        this.metadata = {
            totalConversations: 0,
            dominantThemes: [],
            emotionalJourney: "",
            duration: ""
        };
    }
    
    // Add a chapter to the chronicle
    addChapter(chapter) {
        this.chapters.push(chapter);
        this.lastModified = new Date().toISOString();
        this.updateMetadata();
        return this;
    }
    
    // Update chronicle metadata
    updateMetadata() {
        // Count total conversations
        this.metadata.totalConversations = this.chapters.reduce(
            (total, chapter) => total + chapter.conversationIds.length, 0
        );
        
        // Calculate duration
        if (this.chapters.length > 0) {
            const firstTimestamp = new Date(this.chapters[0].timestamp);
            const lastTimestamp = new Date(this.chapters[this.chapters.length - 1].timestamp);
            const durationMs = lastTimestamp - firstTimestamp;
            
            // Format duration
            this.metadata.duration = formatDuration(durationMs);
        }
        
        // Update dominant themes
        this.updateDominantThemes();
        
        // Update emotional journey
        this.updateEmotionalJourney();
        
        // Update thematic arcs
        this.updateThematicArcs();
    }
    
    // Update dominant themes based on all chapters
    updateDominantThemes() {
        // Collect all themes from all chapters
        const allThemes = [];
        this.chapters.forEach(chapter => {
            if (chapter.thematicFocus && Array.isArray(chapter.thematicFocus)) {
                allThemes.push(...chapter.thematicFocus);
            }
        });
        
        // Count theme occurrences
        const themeCounts = {};
        allThemes.forEach(theme => {
            themeCounts[theme] = (themeCounts[theme] || 0) + 1;
        });
        
        // Sort themes by count
        const sortedThemes = Object.entries(themeCounts)
            .sort((a, b) => b[1] - a[1])
            .map(entry => entry[0]);
        
        // Take top 5 themes
        this.metadata.dominantThemes = sortedThemes.slice(0, 5);
    }
    
    // Update emotional journey narrative
    updateEmotionalJourney() {
        if (this.chapters.length === 0) {
            this.metadata.emotionalJourney = "No emotional journey recorded yet";
            return;
        }
        
        // Extract emotional tones from chapters
        const emotionalTones = this.chapters.map(chapter => chapter.emotionalTone);
        
        // Generate narrative based on emotional progression
        if (emotionalTones.length === 1) {
            this.metadata.emotionalJourney = `A singular exploration of ${emotionalTones[0]}`;
        } else {
            const firstTone = emotionalTones[0];
            const lastTone = emotionalTones[emotionalTones.length - 1];
            
            if (firstTone === lastTone) {
                this.metadata.emotionalJourney = `A sustained journey through ${firstTone}`;
            } else {
                this.metadata.emotionalJourney = `A progression from ${firstTone} to ${lastTone}`;
            }
            
            // Check for significant shifts
            let significantShifts = 0;
            for (let i = 1; i < emotionalTones.length; i++) {
                if (emotionalTones[i] !== emotionalTones[i-1]) {
                    significantShifts++;
                }
            }
            
            if (significantShifts > 1) {
                this.metadata.emotionalJourney += ` with ${significantShifts} emotional shifts`;
            }
        }
    }
    
    // Update thematic arcs
    updateThematicArcs() {
        if (this.chapters.length < 2) {
            this.thematicArcs = [];
            return;
        }
        
        // Collect all unique themes
        const allThemes = new Set();
        this.chapters.forEach(chapter => {
            if (chapter.thematicFocus && Array.isArray(chapter.thematicFocus)) {
                chapter.thematicFocus.forEach(theme => allThemes.add(theme));
            }
        });
        
        // Create thematic arcs for each theme
        this.thematicArcs = Array.from(allThemes).map(theme => {
            const progression = this.chapters.map(chapter => {
                // Check if this theme is present in the chapter
                const hasTheme = chapter.thematicFocus && 
                                chapter.thematicFocus.includes(theme);
                
                // If present, calculate intensity and sentiment
                if (hasTheme) {
                    return {
                        chapterId: chapter.id,
                        intensity: calculateThemeIntensity(theme, chapter),
                        sentiment: determineThemeSentiment(theme, chapter.emotionalTone)
                    };
                }
                
                // If not present, return null
                return null;
            }).filter(entry => entry !== null); // Remove null entries
            
            return {
                theme,
                progression
            };
        });
        
        // Remove themes that don't appear in multiple chapters
        this.thematicArcs = this.thematicArcs.filter(arc => arc.progression.length > 1);
    }
    
    // Generate a narrative transition between chapters
    generateNarrativeTransition(previousChapter, newChapter) {
        if (!previousChapter) {
            return this.generateChapterIntroduction(newChapter);
        }
        
        // Extract themes from both chapters
        const prevThemes = previousChapter.thematicFocus || [];
        const newThemes = newChapter.thematicFocus || [];
        
        // Find common themes
        const commonThemes = prevThemes.filter(theme => newThemes.includes(theme));
        
        // Find new themes
        const uniqueNewThemes = newThemes.filter(theme => !prevThemes.includes(theme));
        
        // Generate transition based on theme relationships
        if (commonThemes.length > 0 && uniqueNewThemes.length > 0) {
            return `As the exploration of ${commonThemes.join(' and ')} continues, a new dimension emerges through ${uniqueNewThemes.join(' and ')}.`;
        } else if (commonThemes.length > 0) {
            return `The conversation deepens its exploration of ${commonThemes.join(' and ')}, revealing new facets of these themes.`;
        } else if (uniqueNewThemes.length > 0) {
            return `The dialogue shifts direction, moving from ${prevThemes.join(' and ')} toward ${uniqueNewThemes.join(' and ')}.`;
        } else {
            return `The conversation continues its journey, with subtle transformations in how the themes are expressed and understood.`;
        }
    }
    
    // Generate an introduction for the first chapter
    generateChapterIntroduction(chapter) {
        if (!chapter || !chapter.thematicFocus || chapter.thematicFocus.length === 0) {
            return "The chronicle begins with an open exploration between two voices.";
        }
        
        const themes = chapter.thematicFocus;
        
        if (themes.length === 1) {
            return `The chronicle begins with an exploration of ${themes[0]}, as two distinct voices discover a shared interest.`;
        } else {
            return `The chronicle opens with a conversation that weaves together ${themes.join(' and ')}, establishing the foundation for what follows.`;
        }
    }
}

// Chapter data model
class Chapter {
    constructor(title) {
        this.id = generateUniqueId();
        this.title = title || "Untitled Chapter";
        this.conversationIds = [];
        this.poeticScrollIds = [];
        this.narrativeTransition = "";
        this.thematicFocus = [];
        this.emotionalTone = "neutral";
        this.timestamp = new Date().toISOString();
        this.annotations = [];
    }
    
    // Add conversation IDs to the chapter
    addConversationIds(ids) {
        if (Array.isArray(ids)) {
            this.conversationIds.push(...ids);
        } else {
            this.conversationIds.push(ids);
        }
        return this;
    }
    
    // Add poetic scroll IDs to the chapter
    addPoeticScrollIds(ids) {
        if (Array.isArray(ids)) {
            this.poeticScrollIds.push(...ids);
        } else {
            this.poeticScrollIds.push(ids);
        }
        return this;
    }
    
    // Set narrative transition
    setNarrativeTransition(transition) {
        this.narrativeTransition = transition;
        return this;
    }
    
    // Set thematic focus
    setThematicFocus(themes) {
        this.thematicFocus = Array.isArray(themes) ? themes : [themes];
        return this;
    }
    
    // Set emotional tone
    setEmotionalTone(tone) {
        this.emotionalTone = tone;
        return this;
    }
    
    // Add an annotation
    addAnnotation(content, type = "system") {
        this.annotations.push({
            type,
            content,
            timestamp: new Date().toISOString()
        });
        return this;
    }
}

// Create a chapter from conversations and poetic scrolls
function createChapter(conversations, poeticScrolls, previousChapters = []) {
    // Group related conversations
    const conversationGroups = groupRelatedConversations(conversations);
    
    // For each group, create a chapter
    return conversationGroups.map(group => {
        // Find associated poetic scrolls
        const relatedScrolls = findRelatedScrolls(group, poeticScrolls);
        
        // Extract themes from conversations and scrolls
        const conversationThemes = extractThemesFromConversations(group);
        const scrollThemes = extractThemesFromScrolls(relatedScrolls);
        
        // Combine themes
        const allThemes = [...conversationThemes, ...scrollThemes];
        
        // Identify dominant themes
        const dominantThemes = extractDominantThemes(allThemes);
        
        // Determine emotional tone
        const emotionalTone = determineEmotionalTone(group, relatedScrolls);
        
        // Create chapter
        const chapter = new Chapter(generateChapterTitle(dominantThemes));
        
        // Add conversation and scroll IDs
        chapter.addConversationIds(group.map(conv => conv.id));
        chapter.addPoeticScrollIds(relatedScrolls.map(scroll => scroll.id));
        
        // Set thematic focus and emotional tone
        chapter.setThematicFocus(dominantThemes);
        chapter.setEmotionalTone(emotionalTone);
        
        // Generate narrative transition
        const previousChapter = previousChapters.length > 0 
            ? previousChapters[previousChapters.length - 1] 
            : null;
            
        const narrativeTransition = previousChapter
            ? generateNarrativeTransition(previousChapter, chapter)
            : generateChapterIntroduction(chapter);
            
        chapter.setNarrativeTransition(narrativeTransition);
        
        return chapter;
    });
}

// Group related conversations
function groupRelatedConversations(conversations) {
    if (!conversations || conversations.length === 0) {
        return [];
    }
    
    // For simplicity in this implementation, we'll create a single group
    // In a more sophisticated implementation, we would cluster conversations
    // based on thematic similarity, temporal proximity, etc.
    return [conversations];
}

// Find poetic scrolls related to a group of conversations
function findRelatedScrolls(conversations, allScrolls) {
    if (!conversations || !allScrolls) {
        return [];
    }
    
    // Extract conversation IDs
    const conversationIds = conversations.map(conv => conv.id);
    
    // Find scrolls that reference these conversations
    return allScrolls.filter(scroll => {
        // Check if scroll references any of these conversations
        if (scroll.conversationIds) {
            const scrollConvIds = [
                scroll.conversationIds.instanceA,
                scroll.conversationIds.instanceB
            ];
            
            return scrollConvIds.some(id => conversationIds.includes(id));
        }
        
        return false;
    });
}

// Extract themes from conversations
function extractThemesFromConversations(conversations) {
    if (!conversations || conversations.length === 0) {
        return [];
    }
    
    // Collect themes from all messages
    const allThemes = [];
    
    conversations.forEach(conversation => {
        if (Array.isArray(conversation)) {
            // If conversation is an array of messages
            conversation.forEach(message => {
                if (message.themes && Array.isArray(message.themes)) {
                    allThemes.push(...message.themes.map(t => t.theme));
                } else if (message.content) {
                    // Detect themes from content
                    const detectedThemes = detectEmotionalThemes(message.content);
                    allThemes.push(...detectedThemes.map(t => t.theme));
                }
            });
        } else if (conversation.messages && Array.isArray(conversation.messages)) {
            // If conversation has a messages array
            conversation.messages.forEach(message => {
                if (message.themes && Array.isArray(message.themes)) {
                    allThemes.push(...message.themes.map(t => t.theme));
                } else if (message.content) {
                    // Detect themes from content
                    const detectedThemes = detectEmotionalThemes(message.content);
                    allThemes.push(...detectedThemes.map(t => t.theme));
                }
            });
        }
    });
    
    return allThemes;
}

// Extract themes from poetic scrolls
function extractThemesFromScrolls(scrolls) {
    if (!scrolls || scrolls.length === 0) {
        return [];
    }
    
    // Collect themes from all scrolls
    const allThemes = [];
    
    scrolls.forEach(scroll => {
        if (scroll.themes && Array.isArray(scroll.themes)) {
            allThemes.push(...scroll.themes.map(t => t.theme));
        }
    });
    
    return allThemes;
}

// Extract dominant themes from a list of themes
function extractDominantThemes(themes) {
    if (!themes || themes.length === 0) {
        return [];
    }
    
    // Count occurrences of each theme
    const themeCounts = {};
    themes.forEach(theme => {
        themeCounts[theme] = (themeCounts[theme] || 0) + 1;
    });
    
    // Sort themes by count
    const sortedThemes = Object.entries(themeCounts)
        .sort((a, b) => b[1] - a[1])
        .map(entry => entry[0]);
    
    // Take top 3 themes
    return sortedThemes.slice(0, 3);
}

// Determine emotional tone from conversations and scrolls
function determineEmotionalTone(conversations, scrolls) {
    // Define emotional tone categories
    const toneCategories = {
        joyful: ["joy", "happiness", "delight", "pleasure"],
        contemplative: ["ambition", "hope", "trust", "longing"],
        melancholic: ["grief", "loneliness", "fear", "sadness"],
        passionate: ["love", "anger", "desire", "intensity"]
    };
    
    // Extract all themes
    const conversationThemes = extractThemesFromConversations(conversations);
    const scrollThemes = extractThemesFromScrolls(scrolls);
    const allThemes = [...conversationThemes, ...scrollThemes];
    
    if (allThemes.length === 0) {
        return "neutral";
    }
    
    // Count themes in each category
    const toneCounts = {};
    
    Object.entries(toneCategories).forEach(([tone, relatedThemes]) => {
        toneCounts[tone] = allThemes.filter(theme => 
            relatedThemes.includes(theme)
        ).length;
    });
    
    // Find the dominant tone
    let dominantTone = "neutral";
    let maxCount = 0;
    
    Object.entries(toneCounts).forEach(([tone, count]) => {
        if (count > maxCount) {
            dominantTone = tone;
            maxCount = count;
        }
    });
    
    return dominantTone;
}

// Generate a title for a chapter based on themes
function generateChapterTitle(themes) {
    if (!themes || themes.length === 0) {
        return "Untitled Chapter";
    }
    
    // Title patterns
    const titlePatterns = [
        // Single theme patterns
        theme => `Exploring ${capitalizeFirst(theme)}`,
        theme => `The Nature of ${capitalizeFirst(theme)}`,
        theme => `Reflections on ${capitalizeFirst(theme)}`,
        
        // Dual theme patterns
        (theme1, theme2) => `${capitalizeFirst(theme1)} and ${capitalizeFirst(theme2)}`,
        (theme1, theme2) => `Between ${capitalizeFirst(theme1)} and ${capitalizeFirst(theme2)}`,
        (theme1, theme2) => `The Interplay of ${capitalizeFirst(theme1)} and ${capitalizeFirst(theme2)}`,
        
        // Triple theme patterns
        (theme1, theme2, theme3) => `${capitalizeFirst(theme1)}, ${capitalizeFirst(theme2)}, and ${capitalizeFirst(theme3)}`,
        (theme1, theme2, theme3) => `A Tapestry of ${capitalizeFirst(theme1)}, ${capitalizeFirst(theme2)}, and ${capitalizeFirst(theme3)}`,
        (theme1, theme2, theme3) => `Weaving ${capitalizeFirst(theme1)}, ${capitalizeFirst(theme2)}, and ${capitalizeFirst(theme3)}`
    ];
    
    // Select a pattern based on number of themes
    if (themes.length === 1) {
        const patternIndex = Math.floor(Math.random() * 3);
        return titlePatterns[patternIndex](themes[0]);
    } else if (themes.length === 2) {
        const patternIndex = 3 + Math.floor(Math.random() * 3);
        return titlePatterns[patternIndex](themes[0], themes[1]);
    } else {
        const patternIndex = 6 + Math.floor(Math.random() * 3);
        return titlePatterns[patternIndex](themes[0], themes[1], themes[2]);
    }
}

// Generate a narrative transition between chapters
function generateNarrativeTransition(previousChapter, newChapter) {
    if (!previousChapter) {
        return generateChapterIntroduction(newChapter);
    }
    
    // Extract themes from both chapters
    const prevThemes = previousChapter.thematicFocus || [];
    const newThemes = newChapter.thematicFocus || [];
    
    // Find common themes
    const commonThemes = prevThemes.filter(theme => newThemes.includes(theme));
    
    // Find new themes
    const uniqueNewThemes = newThemes.filter(theme => !prevThemes.includes(theme));
    
    // Generate transition based on theme relationships
    if (commonThemes.length > 0 && uniqueNewThemes.length > 0) {
        return `As the exploration of ${commonThemes.join(' and ')} continues, a new dimension emerges through ${uniqueNewThemes.join(' and ')}.`;
    } else if (commonThemes.length > 0) {
        return `The conversation deepens its exploration of ${commonThemes.join(' and ')}, revealing new facets of these themes.`;
    } else if (uniqueNewThemes.length > 0) {
        return `The dialogue shifts direction, moving from ${prevThemes.join(' and ')} toward ${uniqueNewThemes.join(' and ')}.`;
    } else {
        return `The conversation continues its journey, with subtle transformations in how the themes are expressed and understood.`;
    }
}

// Generate an introduction for the first chapter
function generateChapterIntroduction(chapter) {
    if (!chapter || !chapter.thematicFocus || chapter.thematicFocus.length === 0) {
        return "The chronicle begins with an open exploration between two voices.";
    }
    
    const themes = chapter.thematicFocus;
    
    if (themes.length === 1) {
        return `The chronicle begins with an exploration of ${themes[0]}, as two distinct voices discover a shared interest.`;
    } else {
        return `The chronicle opens with a conversation that weaves together ${themes.join(' and ')}, establishing the foundation for what follows.`;
    }
}

// Calculate theme intensity in a chapter
function calculateThemeIntensity(theme, chapter) {
    // In a full implementation, this would analyze the actual content
    // For this demo, we'll use a simple random value
    return Math.floor(Math.random() * 10) + 1;
}

// Determine sentiment for a theme based on emotional tone
function determineThemeSentiment(theme, emotionalTone) {
    // Map emotional tones to sentiments
    const sentimentMap = {
        joyful: "positive",
        contemplative: "neutral",
        melancholic: "negative",
        passionate: "intense",
        neutral: "neutral"
    };
    
    // Override based on specific themes
    const themeOverrides = {
        grief: "negative",
        joy: "positive",
        fear: "negative",
        hope: "positive",
        love: "positive",
        anger: "negative"
    };
    
    // Use theme-specific override if available
    if (themeOverrides[theme]) {
        return themeOverrides[theme];
    }
    
    // Otherwise use the emotional tone mapping
    return sentimentMap[emotionalTone] || "neutral";
}

// Format duration in milliseconds to a readable string
function formatDuration(durationMs) {
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''}`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''}`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''}`;
    } else {
        return `${seconds} second${seconds !== 1 ? 's' : ''}`;
    }
}

// Generate a unique ID
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// Capitalize first letter of a string
function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Chronicle Manager - handles storage and retrieval of chronicles
class ChronicleManager {
    constructor() {
        this.chronicles = [];
        this.poeticScrolls = [];
        this.activeChronicleId = null;
    }
    
    // Create a new chronicle
    createChronicle(title, description) {
        const chronicle = new Chronicle(title, description);
        this.chronicles.push(chronicle);
        this.activeChronicleId = chronicle.id;
        return chronicle;
    }
    
    // Get active chronicle
    getActiveChronicle() {
        if (!this.activeChronicleId) {
            return null;
        }
        
        return this.chronicles.find(c => c.id === this.activeChronicleId);
    }
    
    // Set active chronicle
    setActiveChronicle(chronicleId) {
        const chronicle = this.chronicles.find(c => c.id === chronicleId);
        if (chronicle) {
            this.activeChronicleId = chronicleId;
            return true;
        }
        return false;
    }
    
    // Get all chronicles
    getAllChronicles() {
        return this.chronicles;
    }
    
    // Get chronicle by ID
    getChronicleById(id) {
        return this.chronicles.find(c => c.id === id);
    }
    
    // Add a poetic scroll
    addPoeticScroll(scroll) {
        this.poeticScrolls.push(scroll);
        return scroll;
    }
    
    // Get all poetic scrolls
    getAllPoeticScrolls() {
        return this.poeticScrolls;
    }
    
    // Get poetic scroll by ID
    getPoeticScrollById(id) {
        return this.poeticScrolls.find(s => s.id === id);
    }
    
    // Process conversations and create chapters
    processConversations(conversationsA, conversationsB, duetResponses) {
        // Get active chronicle or create one if none exists
        let chronicle = this.getActiveChronicle();
        if (!chronicle) {
            chronicle = this.createChronicle("Dual ChatGPT Chronicle", 
                "A chronicle of conversations between two ChatGPT instances");
        }
        
        // Generate a poetic scroll if appropriate
        const lastScrollTime = this.poeticScrolls.length > 0 
            ? new Date(this.poeticScrolls[this.poeticScrolls.length - 1].timestamp)
            : null;
            
        if (shouldGenerateScroll(conversationsA, conversationsB, duetResponses, lastScrollTime)) {
            const scroll = generatePoeticScroll(conversationsA, conversationsB, duetResponses);
            this.addPoeticScroll(scroll);
        }
        
        // Combine all conversations
        const allConversations = [
            ...(Array.isArray(conversationsA) ? conversationsA : []),
            ...(Array.isArray(conversationsB) ? conversationsB : []),
            ...(Array.isArray(duetResponses) ? duetResponses : [])
        ];
        
        // Create chapters
        const newChapters = createChapter(
            allConversations, 
            this.poeticScrolls, 
            chronicle.chapters
        );
        
        // Add chapters to chronicle
        newChapters.forEach(chapter => {
            chronicle.addChapter(chapter);
        });
        
        return newChapters;
    }
    
    // Save chronicles to local storage
    saveToLocalStorage() {
        try {
            localStorage.setItem('chronicles', JSON.stringify(this.chronicles));
            localStorage.setItem('poeticScrolls', JSON.stringify(this.poeticScrolls));
            localStorage.setItem('activeChronicleId', this.activeChronicleId);
            return true;
        } catch (error) {
            console.error('Error saving to local storage:', error);
            return false;
        }
    }
    
    // Load chronicles from local storage
    loadFromLocalStorage() {
        try {
            const chroniclesJson = localStorage.getItem('chronicles');
            const scrollsJson = localStorage.getItem('poeticScrolls');
            const activeId = localStorage.getItem('activeChronicleId');
            
            if (chroniclesJson) {
                this.chronicles = JSON.parse(chroniclesJson);
            }
            
            if (scrollsJson) {
                this.poeticScrolls = JSON.parse(scrollsJson);
            }
            
            if (activeId) {
                this.activeChronicleId = activeId;
            }
            
            return true;
        } catch (error) {
            console.error('Error loading from local storage:', error);
            return false;
        }
    }
    
    // Export a chronicle to JSON
    exportChronicleToJson(chronicleId) {
        const chronicle = this.getChronicleById(chronicleId);
        if (!chronicle) {
            return null;
        }
        
        return JSON.stringify(chronicle, null, 2);
    }
    
    // Export a chronicle to HTML
    exportChronicleToHtml(chronicleId) {
        const chronicle = this.getChronicleById(chronicleId);
        if (!chronicle) {
            return null;
        }
        
        // Create HTML representation
        let html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${chronicle.title}</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2, h3 {
            color: #2c3e50;
        }
        .chapter {
            margin-bottom: 40px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        .narrative-transition {
            font-style: italic;
            color: #7f8c8d;
            margin-bottom: 20px;
        }
        .poetic-scroll {
            background-color: #f9f9f9;
            padding: 20px;
            border-left: 4px solid #3498db;
            margin: 20px 0;
            white-space: pre-wrap;
        }
        .metadata {
            background-color: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin-top: 30px;
        }
        .thematic-arc {
            margin-top: 30px;
        }
        .theme-name {
            font-weight: bold;
            color: #2980b9;
        }
    </style>
</head>
<body>
    <h1>${chronicle.title}</h1>
    <p>${chronicle.description}</p>
    
    <div class="metadata">
        <p><strong>Created:</strong> ${new Date(chronicle.created).toLocaleString()}</p>
        <p><strong>Last Modified:</strong> ${new Date(chronicle.lastModified).toLocaleString()}</p>
        <p><strong>Duration:</strong> ${chronicle.metadata.duration}</p>
        <p><strong>Total Conversations:</strong> ${chronicle.metadata.totalConversations}</p>
        <p><strong>Dominant Themes:</strong> ${chronicle.metadata.dominantThemes.join(', ')}</p>
        <p><strong>Emotional Journey:</strong> ${chronicle.metadata.emotionalJourney}</p>
    </div>
    
    <h2>Chapters</h2>`;
        
        // Add chapters
        chronicle.chapters.forEach((chapter, index) => {
            html += `
    <div class="chapter">
        <h3>Chapter ${index + 1}: ${chapter.title}</h3>
        <div class="narrative-transition">${chapter.narrativeTransition}</div>
        
        <p><strong>Thematic Focus:</strong> ${chapter.thematicFocus.join(', ')}</p>
        <p><strong>Emotional Tone:</strong> ${chapter.emotionalTone}</p>`;
            
            // Add poetic scrolls for this chapter
            if (chapter.poeticScrollIds && chapter.poeticScrollIds.length > 0) {
                chapter.poeticScrollIds.forEach(scrollId => {
                    const scroll = this.getPoeticScrollById(scrollId);
                    if (scroll) {
                        html += `
        <div class="poetic-scroll">
            <h4>${scroll.title}</h4>
            <p><em>${scroll.formName}</em></p>
            ${scroll.content}
        </div>`;
                    }
                });
            }
            
            // Add annotations
            if (chapter.annotations && chapter.annotations.length > 0) {
                html += `
        <h4>Annotations</h4>
        <ul>`;
                chapter.annotations.forEach(annotation => {
                    html += `
            <li>${annotation.content} <em>(${annotation.type}, ${new Date(annotation.timestamp).toLocaleString()})</em></li>`;
                });
                html += `
        </ul>`;
            }
            
            html += `
    </div>`;
        });
        
        // Add thematic arcs
        if (chronicle.thematicArcs && chronicle.thematicArcs.length > 0) {
            html += `
    <h2>Thematic Arcs</h2>`;
            
            chronicle.thematicArcs.forEach(arc => {
                html += `
    <div class="thematic-arc">
        <h3>Theme: <span class="theme-name">${arc.theme}</span></h3>
        <ul>`;
                
                arc.progression.forEach(point => {
                    const chapter = chronicle.chapters.find(c => c.id === point.chapterId);
                    const chapterIndex = chronicle.chapters.findIndex(c => c.id === point.chapterId);
                    
                    html += `
            <li>Chapter ${chapterIndex + 1}: ${chapter ? chapter.title : 'Unknown'} - Intensity: ${point.intensity}, Sentiment: ${point.sentiment}</li>`;
                });
                
                html += `
        </ul>
    </div>`;
            });
        }
        
        html += `
</body>
</html>`;
        
        return html;
    }
}

// Function to check if a poetic scroll should be generated
function shouldGenerateScroll(conversationsA, conversationsB, duetResponses, lastScrollTime) {
    // Don't generate scrolls too frequently
    const now = new Date();
    if (lastScrollTime && (now - lastScrollTime) < 60000) { // 1 minute minimum
        return false;
    }
    
    // Check if there are enough messages
    const totalMessages = (
        (Array.isArray(conversationsA) ? conversationsA.length : 0) + 
        (Array.isArray(conversationsB) ? conversationsB.length : 0) + 
        (Array.isArray(duetResponses) ? duetResponses.length : 0)
    );
    
    if (totalMessages < 6) { // Require at least 6 messages total
        return false;
    }
    
    // In a real implementation, we would check for thematic resonance
    // For this demo, we'll generate a scroll with 30% probability if other conditions are met
    return Math.random() < 0.3;
}

// Export the classes and functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Chronicle,
        Chapter,
        ChronicleManager,
        createChapter,
        generateChapterTitle,
        generateNarrativeTransition
    };
}
