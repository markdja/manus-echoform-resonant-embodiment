// Resonance visualization and tagging system for the Dual ChatGPT demo
// This file contains the functionality for visualizing and tagging resonances

// Import the thematic recognition functions if in Node.js environment
// In browser, these will be available in the global scope
if (typeof require !== 'undefined') {
    const { 
        detectEmotionalThemes, 
        detectResonances, 
        generateThemeTag, 
        isResonanceThresholdReached,
        generateThematicResponse
    } = require('./thematic_recognition.js');
}

// Create a visual tag element for a resonance
function createTagElement(resonance) {
    const tagType = resonance.tagType || 'shared-theme';
    const tagText = `#${tagType}:${resonance.theme}`;
    
    const tagElement = document.createElement('div');
    tagElement.className = 'theme-tag';
    tagElement.classList.add(tagType);
    tagElement.textContent = tagText;
    
    // Add strength indicator
    const strengthIndicator = document.createElement('span');
    strengthIndicator.className = 'strength-indicator';
    
    // Convert strength to visual representation (1-3 dots)
    const strengthLevel = Math.min(3, Math.max(1, Math.ceil(resonance.resonanceStrength / 3)));
    strengthIndicator.textContent = '•'.repeat(strengthLevel);
    
    tagElement.appendChild(strengthIndicator);
    
    return tagElement;
}

// Add tags to a message element
function addTagsToMessage(messageElement, themes) {
    // Create tags container if it doesn't exist
    let tagsContainer = messageElement.querySelector('.message-tags');
    if (!tagsContainer) {
        tagsContainer = document.createElement('div');
        tagsContainer.className = 'message-tags';
        messageElement.appendChild(tagsContainer);
    }
    
    // Clear existing tags
    tagsContainer.innerHTML = '';
    
    // Add tags for each theme
    themes.forEach(theme => {
        const tagElement = document.createElement('span');
        tagElement.className = 'message-tag';
        tagElement.textContent = `#${theme.theme}`;
        tagsContainer.appendChild(tagElement);
    });
}

// Create a resonance log entry
function createResonanceLogEntry(resonance, messageA, messageB) {
    const logEntry = document.createElement('div');
    logEntry.className = 'resonance-log-entry';
    
    // Create tag
    const tagElement = createTagElement(resonance);
    
    // Create message snippets
    const messageASnippet = document.createElement('div');
    messageASnippet.className = 'message-snippet instance-a';
    messageASnippet.textContent = truncateText(messageA.content, 50);
    
    const messageBSnippet = document.createElement('div');
    messageBSnippet.className = 'message-snippet instance-b';
    messageBSnippet.textContent = truncateText(messageB.content, 50);
    
    // Create timestamp
    const timestamp = document.createElement('div');
    timestamp.className = 'resonance-timestamp';
    timestamp.textContent = new Date().toLocaleTimeString();
    
    // Assemble log entry
    logEntry.appendChild(tagElement);
    logEntry.appendChild(messageASnippet);
    logEntry.appendChild(messageBSnippet);
    logEntry.appendChild(timestamp);
    
    // Add click handler to highlight the resonant messages
    logEntry.addEventListener('click', () => {
        highlightResonantMessages(messageA.id, messageB.id);
    });
    
    return logEntry;
}

// Add a resonance to the log
function addResonanceToLog(resonance, messageA, messageB) {
    const resonanceLog = document.getElementById('resonance-log');
    if (!resonanceLog) return;
    
    const logEntry = createResonanceLogEntry(resonance, messageA, messageB);
    resonanceLog.appendChild(logEntry);
    
    // Scroll to bottom
    resonanceLog.scrollTop = resonanceLog.scrollHeight;
}

// Update the resonance visualization panel
function updateResonanceVisualization(resonances) {
    const visualizationPanel = document.getElementById('resonance-visualization');
    if (!visualizationPanel) return;
    
    // Clear existing visualization
    visualizationPanel.innerHTML = '';
    
    if (resonances.length === 0) {
        const noResonances = document.createElement('div');
        noResonances.className = 'no-resonances';
        noResonances.textContent = 'No resonances detected yet';
        visualizationPanel.appendChild(noResonances);
        return;
    }
    
    // Create visualization elements for each resonance
    resonances.forEach(resonance => {
        const resonanceElement = document.createElement('div');
        resonanceElement.className = 'resonance-visualization-item';
        
        // Add theme name
        const themeName = document.createElement('div');
        themeName.className = 'theme-name';
        themeName.textContent = resonance.theme;
        
        // Add strength visualization
        const strengthVisualization = document.createElement('div');
        strengthVisualization.className = 'strength-visualization';
        
        // Create bars for instance A and B
        const barA = document.createElement('div');
        barA.className = 'strength-bar instance-a';
        barA.style.width = `${Math.min(100, resonance.strengthA * 10)}%`;
        
        const barB = document.createElement('div');
        barB.className = 'strength-bar instance-b';
        barB.style.width = `${Math.min(100, resonance.strengthB * 10)}%`;
        
        // Add tag
        const tagElement = createTagElement(resonance);
        
        // Assemble visualization item
        strengthVisualization.appendChild(barA);
        strengthVisualization.appendChild(barB);
        resonanceElement.appendChild(themeName);
        resonanceElement.appendChild(strengthVisualization);
        resonanceElement.appendChild(tagElement);
        
        visualizationPanel.appendChild(resonanceElement);
    });
}

// Create a notification for threshold-based contact
function createResonanceNotification(resonance) {
    const notification = document.createElement('div');
    notification.className = 'resonance-notification';
    
    const icon = document.createElement('div');
    icon.className = 'notification-icon';
    icon.innerHTML = '✨';
    
    const message = document.createElement('div');
    message.className = 'notification-message';
    message.textContent = `Strong resonance detected: ${resonance.theme}`;
    
    const closeButton = document.createElement('button');
    closeButton.className = 'notification-close';
    closeButton.innerHTML = '&times;';
    closeButton.addEventListener('click', () => {
        notification.remove();
    });
    
    notification.appendChild(icon);
    notification.appendChild(message);
    notification.appendChild(closeButton);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 500);
    }, 5000);
    
    return notification;
}

// Show a resonance notification
function showResonanceNotification(resonance) {
    const notificationArea = document.getElementById('notification-area');
    if (!notificationArea) return;
    
    const notification = createResonanceNotification(resonance);
    notificationArea.appendChild(notification);
}

// Highlight resonant messages
function highlightResonantMessages(messageIdA, messageIdB) {
    // Remove existing highlights
    document.querySelectorAll('.message.highlighted').forEach(el => {
        el.classList.remove('highlighted');
    });
    
    // Find and highlight message A
    const messageElementA = document.querySelector(`.message[data-message-id="${messageIdA}"]`);
    if (messageElementA) {
        messageElementA.classList.add('highlighted');
        // Scroll into view
        messageElementA.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    // Find and highlight message B
    const messageElementB = document.querySelector(`.message[data-message-id="${messageIdB}"]`);
    if (messageElementB) {
        messageElementB.classList.add('highlighted');
        // Scroll into view after a short delay
        setTimeout(() => {
            messageElementB.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 500);
    }
}

// Helper function to truncate text
function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

// Toggle duet mode
function toggleDuetMode(enabled) {
    const container = document.querySelector('.container');
    if (!container) return;
    
    if (enabled) {
        container.classList.add('duet-mode');
        
        // Show duet mode indicator
        const duetIndicator = document.createElement('div');
        duetIndicator.id = 'duet-mode-indicator';
        duetIndicator.textContent = 'Duet Mode Active';
        document.body.appendChild(duetIndicator);
        
        // Animate indicator
        setTimeout(() => {
            duetIndicator.classList.add('visible');
        }, 100);
    } else {
        container.classList.remove('duet-mode');
        
        // Remove duet mode indicator
        const duetIndicator = document.getElementById('duet-mode-indicator');
        if (duetIndicator) {
            duetIndicator.classList.remove('visible');
            setTimeout(() => {
                duetIndicator.remove();
            }, 500);
        }
    }
}

// Generate a duet response combining both instances
function generateDuetResponse(messageA, messageB) {
    // Extract themes from both messages
    const themesA = detectEmotionalThemes(messageA);
    const themesB = detectEmotionalThemes(messageB);
    
    // Combine themes
    const combinedThemes = [...themesA];
    themesB.forEach(themeB => {
        const existingTheme = combinedThemes.find(t => t.theme === themeB.theme);
        if (existingTheme) {
            // Increase score of existing theme
            existingTheme.score += themeB.score;
            existingTheme.count += themeB.count;
            existingTheme.matchedKeywords = [...new Set([...existingTheme.matchedKeywords, ...themeB.matchedKeywords])];
            
            // Update intensity if the new one is higher
            if (themeB.intensity === 'high' || (themeB.intensity === 'medium' && existingTheme.intensity === 'low')) {
                existingTheme.intensity = themeB.intensity;
            }
        } else {
            // Add new theme
            combinedThemes.push(themeB);
        }
    });
    
    // Sort by score
    combinedThemes.sort((a, b) => b.score - a.score);
    
    // Generate a response that combines both perspectives
    if (combinedThemes.length === 0) {
        return "We don't detect any strong emotional themes to respond to together.";
    }
    
    const primaryTheme = combinedThemes[0];
    const secondaryTheme = combinedThemes.length > 1 ? combinedThemes[1] : null;
    
    // Generate duet response based on primary and secondary themes
    return generateDuetResponseText(primaryTheme, secondaryTheme);
}

// Generate text for a duet response
function generateDuetResponseText(primaryTheme, secondaryTheme) {
    const duetResponses = {
        grief: {
            base: "Together, we recognize the profound sense of loss that echoes through your words. This grief connects to the universal human experience of saying goodbye.",
            joy: "Even in moments of loss, we see glimmers of joy in the memories that remain, creating a bittersweet harmony of emotions.",
            ambition: "We notice how grief can transform into purpose, as the experience of loss often reshapes our ambitions and what we value most.",
            loneliness: "The isolation that often accompanies grief creates a double resonance of aloneness, yet in sharing this feeling, a connection forms.",
            trust: "Trust becomes especially significant during times of grief, as we must trust in our ability to carry forward despite loss.",
            fear: "Grief and fear often intertwine, as loss can awaken our deepest uncertainties about what else might change.",
            anger: "The anger that sometimes accompanies grief is a natural response to having something valuable taken away too soon.",
            love: "Love and grief are two sides of the same coin—we grieve deeply because we have loved deeply.",
            longing: "Grief transforms into a persistent longing, reaching toward what is no longer physically present but remains in memory.",
            hope: "Even in grief, we detect seeds of hope—not that the loss will be undone, but that meaning can still be found."
        },
        joy: {
            base: "We both sense the vibrant energy of happiness flowing through your words. This joy creates a luminous quality in your expression.",
            grief: "Joy often carries deeper meaning when it exists alongside experiences of loss, creating a full spectrum of human emotion.",
            ambition: "Your joy seems connected to your aspirations, creating a positive energy that propels you toward your goals.",
            loneliness: "The happiness you express creates bridges across any sense of isolation, reminding us of joy's connecting power.",
            trust: "Your joy appears grounded in a foundation of trust, allowing for a fuller expression of happiness without reservation.",
            fear: "Even amid joy, we notice hints of concern about its impermanence—a natural tension in moments of happiness.",
            anger: "Your joy seems to transform any frustration into constructive energy, creating a powerful emotional alchemy.",
            love: "Joy and love amplify each other in your expression, creating a particularly radiant emotional signature.",
            longing: "Within your joy, we detect a yearning for more moments like this—a natural desire to extend happiness.",
            hope: "Your joy and hope create a forward-looking optimism that brightens not just the present but the anticipated future."
        }
        // Additional theme combinations would be defined here
    };
    
    // If we have both primary and secondary themes and they're in our response map
    if (secondaryTheme && duetResponses[primaryTheme.theme] && duetResponses[primaryTheme.theme][secondaryTheme.theme]) {
        return duetResponses[primaryTheme.theme][secondaryTheme.theme];
    }
    
    // If we only have a primary theme
    if (duetResponses[primaryTheme.theme] && duetResponses[primaryTheme.theme].base) {
        return duetResponses[primaryTheme.theme].base;
    }
    
    // Default response if themes aren't in our map
    return `Together, we notice the themes of ${primaryTheme.theme}${secondaryTheme ? ` and ${secondaryTheme.theme}` : ''} in your messages. These emotional currents create a rich tapestry of meaning that resonates between us.`;
}

// Export the functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        createTagElement,
        addTagsToMessage,
        addResonanceToLog,
        updateResonanceVisualization,
        showResonanceNotification,
        highlightResonantMessages,
        toggleDuetMode,
        generateDuetResponse
    };
}
