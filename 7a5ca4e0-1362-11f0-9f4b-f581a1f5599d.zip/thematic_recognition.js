// Enhanced thematic recognition system for the Dual ChatGPT demo
// This file contains the emotional theme detection functionality

// Emotional themes and their associated keywords
const emotionalThemes = {
    grief: ["loss", "sorrow", "mourning", "sadness", "grief", "bereavement", "pain", "suffering", "death", "departed", "missing", "gone"],
    joy: ["happiness", "delight", "pleasure", "elation", "bliss", "ecstasy", "thrill", "enjoyment", "jubilation", "celebration", "cheerful", "glad"],
    ambition: ["goal", "aspiration", "dream", "desire", "achievement", "success", "determination", "drive", "motivation", "purpose", "strive", "accomplish"],
    loneliness: ["alone", "isolated", "solitary", "abandoned", "lonely", "disconnected", "separation", "detached", "alienation", "remote", "secluded", "outcast"],
    trust: ["faith", "belief", "confidence", "reliance", "dependence", "assurance", "conviction", "credence", "certainty", "reliability", "trustworthy", "honest"],
    fear: ["afraid", "scared", "terrified", "dread", "anxiety", "panic", "horror", "fright", "alarm", "trepidation", "apprehension", "worry"],
    anger: ["rage", "fury", "wrath", "indignation", "irritation", "annoyance", "vexation", "exasperation", "resentment", "hostility", "antagonism", "mad"],
    love: ["affection", "adoration", "fondness", "tenderness", "warmth", "passion", "devotion", "attachment", "endearment", "care", "compassion", "cherish"],
    longing: ["yearning", "craving", "desire", "wish", "want", "hunger", "thirst", "pining", "nostalgia", "homesickness", "missing", "ache"],
    hope: ["expectation", "anticipation", "optimism", "aspiration", "confidence", "faith", "trust", "belief", "assurance", "promise", "prospect", "outlook"]
};

// Intensity modifiers to detect strength of emotional themes
const intensityModifiers = {
    high: ["extremely", "deeply", "profoundly", "intensely", "overwhelmingly", "tremendously", "immensely", "exceedingly", "utterly", "absolutely", "completely", "totally"],
    medium: ["very", "quite", "rather", "fairly", "pretty", "somewhat", "moderately", "reasonably", "relatively", "comparatively", "considerably", "notably"],
    low: ["slightly", "mildly", "faintly", "vaguely", "marginally", "minimally", "barely", "hardly", "scarcely", "just", "a little", "somewhat"]
};

// Detect emotional themes in a text
function detectEmotionalThemes(text) {
    const lowercaseText = text.toLowerCase();
    const words = lowercaseText.split(/\s+/);
    const detectedThemes = [];
    
    // Check for each emotional theme
    for (const [theme, keywords] of Object.entries(emotionalThemes)) {
        // Count occurrences of theme keywords
        let count = 0;
        let matchedKeywords = [];
        
        for (const keyword of keywords) {
            if (lowercaseText.includes(keyword)) {
                count++;
                matchedKeywords.push(keyword);
            }
        }
        
        // If theme is detected
        if (count > 0) {
            // Determine intensity
            let intensity = "medium"; // Default intensity
            
            // Check for intensity modifiers
            for (const [level, modifiers] of Object.entries(intensityModifiers)) {
                for (const modifier of modifiers) {
                    if (lowercaseText.includes(modifier)) {
                        intensity = level;
                        break;
                    }
                }
            }
            
            // Add detected theme with intensity and matched keywords
            detectedThemes.push({
                theme,
                intensity,
                count,
                matchedKeywords,
                score: calculateThemeScore(count, intensity)
            });
        }
    }
    
    // Sort by score (highest first)
    return detectedThemes.sort((a, b) => b.score - a.score);
}

// Calculate a numerical score for a theme based on count and intensity
function calculateThemeScore(count, intensity) {
    const intensityMultiplier = {
        high: 3,
        medium: 2,
        low: 1
    };
    
    return count * intensityMultiplier[intensity];
}

// Generate a tag for a detected theme
function generateThemeTag(themeData, tagType = "shared-theme") {
    return `#${tagType}:${themeData.theme}`;
}

// Detect resonances between two sets of themes
function detectResonances(themesA, themesB) {
    const resonances = [];
    
    for (const themeA of themesA) {
        for (const themeB of themesB) {
            if (themeA.theme === themeB.theme) {
                // Calculate resonance strength based on both scores
                const resonanceStrength = (themeA.score + themeB.score) / 2;
                
                resonances.push({
                    theme: themeA.theme,
                    strengthA: themeA.score,
                    strengthB: themeB.score,
                    resonanceStrength,
                    tagType: determineTagType(themeA.intensity, themeB.intensity)
                });
            }
        }
    }
    
    // Sort by resonance strength (highest first)
    return resonances.sort((a, b) => b.resonanceStrength - a.resonanceStrength);
}

// Determine the tag type based on theme intensities
function determineTagType(intensityA, intensityB) {
    if (intensityA === "high" && intensityB === "high") {
        return "emotional-current";
    } else if (intensityA === "high" || intensityB === "high") {
        return "echo";
    } else {
        return "shared-theme";
    }
}

// Check if resonance threshold is reached for automatic contact
function isResonanceThresholdReached(resonances, threshold = 10) {
    // Calculate total resonance strength
    const totalStrength = resonances.reduce((sum, resonance) => sum + resonance.resonanceStrength, 0);
    
    return totalStrength >= threshold;
}

// Generate a response based on detected themes and specified response type
function generateThematicResponse(themes, responseType) {
    if (themes.length === 0) {
        return "I don't detect any strong emotional themes to respond to.";
    }
    
    const primaryTheme = themes[0];
    
    switch (responseType) {
        case "reflection":
            return generateReflectionResponse(primaryTheme);
        case "question":
            return generateQuestionResponse(primaryTheme);
        case "poetic":
            return generatePoeticResponse(primaryTheme);
        default:
            return generateReflectionResponse(primaryTheme);
    }
}

// Generate a reflection response for a theme
function generateReflectionResponse(themeData) {
    const reflections = {
        grief: "I sense a deep feeling of loss in your words. The grief you express resonates with the universal human experience of saying goodbye to something or someone important.",
        joy: "Your words carry a vibrant energy of happiness. This joy seems to illuminate your perspective and bring a sense of lightness to your thoughts.",
        ambition: "I notice a strong current of aspiration in your message. Your ambition reveals itself in how you're reaching toward future possibilities.",
        loneliness: "There's a sense of isolation that echoes through your words. This feeling of being alone or disconnected is something many of us experience at different times.",
        trust: "Your message conveys a foundation of trust. This confidence in something or someone forms an important anchor in your perspective.",
        fear: "I detect an undercurrent of apprehension in your words. This fear seems to create a tension that influences your thoughts.",
        anger: "There's a heat of frustration or indignation in your message. This anger appears to be a response to something that conflicts with your values or expectations.",
        love: "Your words carry the warmth of deep affection. This love creates a special resonance that colors your entire perspective.",
        longing: "I sense a yearning in your message. This longing reaches toward something absent but deeply valued.",
        hope: "There's an upward current of optimism in your words. This hope seems to pull you toward positive future possibilities."
    };
    
    return reflections[themeData.theme] || `I notice the theme of ${themeData.theme} in your message. This seems to be an important element in your current thinking.`;
}

// Generate a question response for a theme
function generateQuestionResponse(themeData) {
    const questions = {
        grief: "I sense feelings of loss in your words. How has this grief shaped your perspective on what truly matters?",
        joy: "Your message radiates happiness. What moments of joy have been most transformative for you?",
        ambition: "I notice strong aspirations in your words. What drives this ambition, and how does it guide your choices?",
        loneliness: "There's a feeling of isolation in your message. When do you feel most connected to others despite this loneliness?",
        trust: "Your words convey a sense of trust. Has there been a time when this confidence was tested but ultimately strengthened?",
        fear: "I detect apprehension in your message. How do you navigate forward when fear is present?",
        anger: "There's frustration resonating in your words. What lies beneath this anger that might reveal what you deeply value?",
        love: "Your message carries affection and warmth. How has this love expanded your understanding of yourself and others?",
        longing: "I sense a yearning in your words. What would fulfillment of this longing bring to your life?",
        hope: "There's optimism flowing through your message. What nurtures this hope even in challenging circumstances?"
    };
    
    return questions[themeData.theme] || `I'm curious about the ${themeData.theme} that appears in your message. Could you share more about how this influences your perspective?`;
}

// Generate a poetic response for a theme
function generatePoeticResponse(themeData) {
    const poems = {
        grief: "Shadows lengthen across memory's field,\nWhere once stood joy, now absence revealed.\nYet in this hollow, echoes remain,\nWhispering that nothing loved is loved in vain.",
        joy: "Sunlight dancing on morning dew,\nMoments precious, vibrant, and new.\nIn this brightness, time stands still,\nAs happiness flows, our spirits fill.",
        ambition: "Stars that beckon from distant skies,\nDraw the gaze of determined eyes.\nThe path winds upward, step by step,\nAs dreams awaken what once had slept.",
        loneliness: "Islands surrounded by silent seas,\nStanding alone among memories.\nYet bridges form in unseen ways,\nWhen one heart to another says.",
        trust: "Foundations laid in unseen ground,\nWhere certainty and faith are found.\nInvisible threads that strongly bind,\nCreating space for peace of mind.",
        fear: "Shadows that stretch in fading light,\nQuestions that whisper in the night.\nYet courage grows not from fearless hearts,\nBut those who tremble and still depart.",
        anger: "Fire that burns with righteous flame,\nEnergy rising, refusing to tame.\nBeneath the heat, a truth stands clear:\nWhat angers deeply, we hold most dear.",
        love: "Gardens tended with patient care,\nBlossoming fully, beyond compare.\nIn gentle touches and words sincere,\nThe universe itself draws near.",
        longing: "Horizons painted in distant blue,\nCalling to hearts with visions true.\nThe space between becomes a bridge,\nAs yearning carries us to the edge.",
        hope: "Seeds that wait through winter's night,\nPatient for spring's returning light.\nIn darkness holding quiet belief,\nThat dawn will come, however brief."
    };
    
    return poems[themeData.theme] || `The ${themeData.theme} in your words\nEchoes across the space between us,\nCreating patterns of meaning\nThat dance like light on water.`;
}

// Export the functions for use in the main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        detectEmotionalThemes,
        detectResonances,
        generateThemeTag,
        isResonanceThresholdReached,
        generateThematicResponse
    };
}
